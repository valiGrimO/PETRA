import bpy

# MATERIAL
r2_contourline = bpy.data.materials.new(name='r2_contourline')
r2_contourline.use_nodes = True
node_tree0 = r2_contourline.node_tree
for node in node_tree0.nodes:
    node_tree0.nodes.remove(node)

# NODES
value_0 = node_tree0.nodes.new('ShaderNodeValue')
if hasattr(value_0, 'color'):
    value_0.color = (0.6079999804496765, 0.6079999804496765, 0.6079999804496765)
if hasattr(value_0, 'hide'):
    value_0.hide = False
if hasattr(value_0, 'label'):
    value_0.label = '... mm'
if hasattr(value_0, 'location'):
    value_0.location = (0.0, 0.0)
if hasattr(value_0, 'mute'):
    value_0.mute = False
if hasattr(value_0, 'name'):
    value_0.name = 'Value'
if hasattr(value_0, 'use_custom_color'):
    value_0.use_custom_color = False
if hasattr(value_0, 'width'):
    value_0.width = 140.0
value_0.outputs[0].default_value = 1.0

node_tree1 = bpy.data.node_groups.get('NodeGroup.001')
if not node_tree1:
    node_tree1 = bpy.data.node_groups.new('NodeGroup.001', 'ShaderNodeTree')
    # INPUTS
    node_tree1.inputs.new('NodeSocketFloat', 'Value')
    # OUTPUTS
    node_tree1.outputs.new('NodeSocketShader', 'CL1')
    node_tree1.outputs.new('NodeSocketShader', 'CL2')
    node_tree1.outputs.new('NodeSocketShader', 'CL3')
    # NODES
    math_1 = node_tree1.nodes.new('ShaderNodeMath')
    if hasattr(math_1, 'color'):
        math_1.color = (0.6079999804496765, 0.6079999804496765, 0.6079999804496765)
    if hasattr(math_1, 'hide'):
        math_1.hide = False
    if hasattr(math_1, 'label'):
        math_1.label = 'x1'
    if hasattr(math_1, 'location'):
        math_1.location = (-380.0, -40.0)
    if hasattr(math_1, 'mute'):
        math_1.mute = False
    if hasattr(math_1, 'name'):
        math_1.name = 'Math'
    if hasattr(math_1, 'operation'):
        math_1.operation = 'DIVIDE'
    if hasattr(math_1, 'use_clamp'):
        math_1.use_clamp = False
    if hasattr(math_1, 'use_custom_color'):
        math_1.use_custom_color = False
    if hasattr(math_1, 'width'):
        math_1.width = 140.0
    math_1.inputs[0].default_value = 200.0
    math_1.inputs[1].default_value = 1.0
    math_1.inputs[2].default_value = 0.0
    math_1.outputs[0].default_value = 0.0

    group_input_1 = node_tree1.nodes.new('NodeGroupInput')
    if hasattr(group_input_1, 'color'):
        group_input_1.color = (0.6079999804496765, 0.6079999804496765, 0.6079999804496765)
    if hasattr(group_input_1, 'hide'):
        group_input_1.hide = False
    if hasattr(group_input_1, 'location'):
        group_input_1.location = (-580.0, -120.0)
    if hasattr(group_input_1, 'mute'):
        group_input_1.mute = False
    if hasattr(group_input_1, 'name'):
        group_input_1.name = 'Group Input'
    if hasattr(group_input_1, 'use_custom_color'):
        group_input_1.use_custom_color = False
    if hasattr(group_input_1, 'width'):
        group_input_1.width = 140.0
    group_input_1.outputs[0].default_value = 1.0

    node_tree2 = bpy.data.node_groups.get('NodeGroup')
    if not node_tree2:
        node_tree2 = bpy.data.node_groups.new('NodeGroup', 'ShaderNodeTree')
        # INPUTS
        node_tree2.inputs.new('NodeSocketVectorXYZ', 'Scale')
        # OUTPUTS
        node_tree2.outputs.new('NodeSocketShader', 'Shader')
        # NODES
        texture_coordinate_2 = node_tree2.nodes.new('ShaderNodeTexCoord')
        if hasattr(texture_coordinate_2, 'color'):
            texture_coordinate_2.color = (0.6079999804496765, 0.6079999804496765, 0.6079999804496765)
        if hasattr(texture_coordinate_2, 'from_instancer'):
            texture_coordinate_2.from_instancer = False
        if hasattr(texture_coordinate_2, 'hide'):
            texture_coordinate_2.hide = False
        if hasattr(texture_coordinate_2, 'location'):
            texture_coordinate_2.location = (-510.0, 181.0)
        if hasattr(texture_coordinate_2, 'mute'):
            texture_coordinate_2.mute = False
        if hasattr(texture_coordinate_2, 'name'):
            texture_coordinate_2.name = 'Texture Coordinate'
        if hasattr(texture_coordinate_2, 'use_custom_color'):
            texture_coordinate_2.use_custom_color = False
        if hasattr(texture_coordinate_2, 'width'):
            texture_coordinate_2.width = 140.0
        texture_coordinate_2.outputs[0].default_value = (0.0, 0.0, 0.0)
        texture_coordinate_2.outputs[1].default_value = (0.0, 0.0, 0.0)
        texture_coordinate_2.outputs[2].default_value = (0.0, 0.0, 0.0)
        texture_coordinate_2.outputs[3].default_value = (0.0, 0.0, 0.0)
        texture_coordinate_2.outputs[4].default_value = (0.0, 0.0, 0.0)
        texture_coordinate_2.outputs[5].default_value = (0.0, 0.0, 0.0)
        texture_coordinate_2.outputs[6].default_value = (0.0, 0.0, 0.0)

        vector_transform_2 = node_tree2.nodes.new('ShaderNodeVectorTransform')
        if hasattr(vector_transform_2, 'color'):
            vector_transform_2.color = (0.6079999804496765, 0.6079999804496765, 0.6079999804496765)
        if hasattr(vector_transform_2, 'convert_from'):
            vector_transform_2.convert_from = 'WORLD'
        if hasattr(vector_transform_2, 'convert_to'):
            vector_transform_2.convert_to = 'OBJECT'
        if hasattr(vector_transform_2, 'hide'):
            vector_transform_2.hide = False
        if hasattr(vector_transform_2, 'location'):
            vector_transform_2.location = (-340.0, 181.0)
        if hasattr(vector_transform_2, 'mute'):
            vector_transform_2.mute = False
        if hasattr(vector_transform_2, 'name'):
            vector_transform_2.name = 'Vector Transform'
        if hasattr(vector_transform_2, 'use_custom_color'):
            vector_transform_2.use_custom_color = False
        if hasattr(vector_transform_2, 'vector_type'):
            vector_transform_2.vector_type = 'VECTOR'
        if hasattr(vector_transform_2, 'width'):
            vector_transform_2.width = 140.0
        vector_transform_2.inputs[0].default_value = (0.5, 0.5, 0.5)
        vector_transform_2.outputs[0].default_value = (0.0, 0.0, 0.0)

        mapping_2 = node_tree2.nodes.new('ShaderNodeMapping')
        if hasattr(mapping_2, 'color'):
            mapping_2.color = (0.6079999804496765, 0.6079999804496765, 0.6079999804496765)
        if hasattr(mapping_2, 'hide'):
            mapping_2.hide = False
        if hasattr(mapping_2, 'location'):
            mapping_2.location = (-170.0, 181.0)
        if hasattr(mapping_2, 'mute'):
            mapping_2.mute = False
        if hasattr(mapping_2, 'name'):
            mapping_2.name = 'Mapping'
        if hasattr(mapping_2, 'use_custom_color'):
            mapping_2.use_custom_color = False
        if hasattr(mapping_2, 'vector_type'):
            mapping_2.vector_type = 'POINT'
        if hasattr(mapping_2, 'width'):
            mapping_2.width = 140.0
        mapping_2.inputs[0].default_value = (0.0, 0.0, 0.0)
        mapping_2.inputs[1].default_value = (0.0, 0.0, 0.0)
        mapping_2.inputs[2].default_value = (0.0, 1.5707963705062866, 0.0)
        mapping_2.inputs[3].default_value = (1.0, 1.0, 1.0)
        mapping_2.outputs[0].default_value = (0.0, 0.0, 0.0)

        separate_xyz_2 = node_tree2.nodes.new('ShaderNodeSeparateXYZ')
        if hasattr(separate_xyz_2, 'color'):
            separate_xyz_2.color = (0.6079999804496765, 0.6079999804496765, 0.6079999804496765)
        if hasattr(separate_xyz_2, 'hide'):
            separate_xyz_2.hide = False
        if hasattr(separate_xyz_2, 'location'):
            separate_xyz_2.location = (0.0, 181.0)
        if hasattr(separate_xyz_2, 'mute'):
            separate_xyz_2.mute = False
        if hasattr(separate_xyz_2, 'name'):
            separate_xyz_2.name = 'Separate XYZ'
        if hasattr(separate_xyz_2, 'use_custom_color'):
            separate_xyz_2.use_custom_color = False
        if hasattr(separate_xyz_2, 'width'):
            separate_xyz_2.width = 140.0
        separate_xyz_2.inputs[0].default_value = (0.0, 0.0, 0.0)
        separate_xyz_2.outputs[0].default_value = 0.0
        separate_xyz_2.outputs[1].default_value = 0.0
        separate_xyz_2.outputs[2].default_value = 0.0

        checker_texture_2 = node_tree2.nodes.new('ShaderNodeTexChecker')
        if hasattr(checker_texture_2, 'color'):
            checker_texture_2.color = (0.6079999804496765, 0.6079999804496765, 0.6079999804496765)
        if hasattr(checker_texture_2, 'hide'):
            checker_texture_2.hide = False
        if hasattr(checker_texture_2, 'location'):
            checker_texture_2.location = (170.0, 181.0)
        if hasattr(checker_texture_2, 'mute'):
            checker_texture_2.mute = False
        if hasattr(checker_texture_2, 'name'):
            checker_texture_2.name = 'Checker Texture'
        if hasattr(checker_texture_2, 'use_custom_color'):
            checker_texture_2.use_custom_color = False
        if hasattr(checker_texture_2, 'width'):
            checker_texture_2.width = 140.0
        checker_texture_2.inputs[0].default_value = (0.0, 0.0, 0.0)
        checker_texture_2.inputs[1].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
        checker_texture_2.inputs[2].default_value = (0.0, 0.0, 0.0, 1.0)
        checker_texture_2.inputs[3].default_value = 5.0
        checker_texture_2.outputs[0].default_value = (0.0, 0.0, 0.0, 0.0)
        checker_texture_2.outputs[1].default_value = 0.0

        geometry_2 = node_tree2.nodes.new('ShaderNodeNewGeometry')
        if hasattr(geometry_2, 'color'):
            geometry_2.color = (0.6079999804496765, 0.6079999804496765, 0.6079999804496765)
        if hasattr(geometry_2, 'hide'):
            geometry_2.hide = False
        if hasattr(geometry_2, 'location'):
            geometry_2.location = (338.1522216796875, 429.027099609375)
        if hasattr(geometry_2, 'mute'):
            geometry_2.mute = False
        if hasattr(geometry_2, 'name'):
            geometry_2.name = 'Geometry'
        if hasattr(geometry_2, 'use_custom_color'):
            geometry_2.use_custom_color = False
        if hasattr(geometry_2, 'width'):
            geometry_2.width = 140.0
        geometry_2.outputs[0].default_value = (0.0, 0.0, 0.0)
        geometry_2.outputs[1].default_value = (0.0, 0.0, 0.0)
        geometry_2.outputs[2].default_value = (0.0, 0.0, 0.0)
        geometry_2.outputs[3].default_value = (0.0, 0.0, 0.0)
        geometry_2.outputs[4].default_value = (0.0, 0.0, 0.0)
        geometry_2.outputs[5].default_value = (0.0, 0.0, 0.0)
        geometry_2.outputs[6].default_value = 0.0
        geometry_2.outputs[7].default_value = 0.0
        geometry_2.outputs[8].default_value = 0.0

        emission_2 = node_tree2.nodes.new('ShaderNodeEmission')
        if hasattr(emission_2, 'color'):
            emission_2.color = (0.6079999804496765, 0.6079999804496765, 0.6079999804496765)
        if hasattr(emission_2, 'hide'):
            emission_2.hide = False
        if hasattr(emission_2, 'location'):
            emission_2.location = (338.1522216796875, 183.027099609375)
        if hasattr(emission_2, 'mute'):
            emission_2.mute = False
        if hasattr(emission_2, 'name'):
            emission_2.name = 'Emission'
        if hasattr(emission_2, 'use_custom_color'):
            emission_2.use_custom_color = False
        if hasattr(emission_2, 'width'):
            emission_2.width = 140.0
        emission_2.inputs[0].default_value = (1.0, 1.0, 1.0, 1.0)
        emission_2.inputs[1].default_value = 1.0

        emission_001_2 = node_tree2.nodes.new('ShaderNodeEmission')
        if hasattr(emission_001_2, 'color'):
            emission_001_2.color = (0.6079999804496765, 0.6079999804496765, 0.6079999804496765)
        if hasattr(emission_001_2, 'hide'):
            emission_001_2.hide = False
        if hasattr(emission_001_2, 'location'):
            emission_001_2.location = (338.1522216796875, 67.027099609375)
        if hasattr(emission_001_2, 'mute'):
            emission_001_2.mute = False
        if hasattr(emission_001_2, 'name'):
            emission_001_2.name = 'Emission.001'
        if hasattr(emission_001_2, 'use_custom_color'):
            emission_001_2.use_custom_color = False
        if hasattr(emission_001_2, 'width'):
            emission_001_2.width = 140.0
        emission_001_2.inputs[0].default_value = (1.0, 1.0, 1.0, 1.0)
        emission_001_2.inputs[1].default_value = 1.0

        group_input_2 = node_tree2.nodes.new('NodeGroupInput')
        if hasattr(group_input_2, 'color'):
            group_input_2.color = (0.6079999804496765, 0.6079999804496765, 0.6079999804496765)
        if hasattr(group_input_2, 'hide'):
            group_input_2.hide = False
        if hasattr(group_input_2, 'location'):
            group_input_2.location = (-339.6327209472656, -44.058349609375)
        if hasattr(group_input_2, 'mute'):
            group_input_2.mute = False
        if hasattr(group_input_2, 'name'):
            group_input_2.name = 'Group Input'
        if hasattr(group_input_2, 'use_custom_color'):
            group_input_2.use_custom_color = False
        if hasattr(group_input_2, 'width'):
            group_input_2.width = 140.0
        group_input_2.outputs[0].default_value = (1.0, 1.0, 1.0)

        mix_shader_2 = node_tree2.nodes.new('ShaderNodeMixShader')
        if hasattr(mix_shader_2, 'color'):
            mix_shader_2.color = (0.6079999804496765, 0.6079999804496765, 0.6079999804496765)
        if hasattr(mix_shader_2, 'hide'):
            mix_shader_2.hide = False
        if hasattr(mix_shader_2, 'location'):
            mix_shader_2.location = (519.238525390625, 236.5284423828125)
        if hasattr(mix_shader_2, 'mute'):
            mix_shader_2.mute = False
        if hasattr(mix_shader_2, 'name'):
            mix_shader_2.name = 'Mix Shader'
        if hasattr(mix_shader_2, 'use_custom_color'):
            mix_shader_2.use_custom_color = False
        if hasattr(mix_shader_2, 'width'):
            mix_shader_2.width = 140.0
        mix_shader_2.inputs[0].default_value = 0.5

        group_output_2 = node_tree2.nodes.new('NodeGroupOutput')
        if hasattr(group_output_2, 'color'):
            group_output_2.color = (0.6079999804496765, 0.6079999804496765, 0.6079999804496765)
        if hasattr(group_output_2, 'hide'):
            group_output_2.hide = False
        if hasattr(group_output_2, 'is_active_output'):
            group_output_2.is_active_output = True
        if hasattr(group_output_2, 'location'):
            group_output_2.location = (692.6092529296875, 235.0704345703125)
        if hasattr(group_output_2, 'mute'):
            group_output_2.mute = False
        if hasattr(group_output_2, 'name'):
            group_output_2.name = 'Group Output'
        if hasattr(group_output_2, 'use_custom_color'):
            group_output_2.use_custom_color = False
        if hasattr(group_output_2, 'width'):
            group_output_2.width = 140.0

        # LINKS
        node_tree2.links.new(mix_shader_2.outputs[0], group_output_2.inputs[0])
        node_tree2.links.new(group_input_2.outputs[0], mapping_2.inputs[3])
        node_tree2.links.new(mapping_2.outputs[0], separate_xyz_2.inputs[0])
        node_tree2.links.new(separate_xyz_2.outputs[0], checker_texture_2.inputs[0])
        node_tree2.links.new(vector_transform_2.outputs[0], mapping_2.inputs[0])
        node_tree2.links.new(texture_coordinate_2.outputs[4], vector_transform_2.inputs[0])
        node_tree2.links.new(checker_texture_2.outputs[0], emission_2.inputs[0])
        node_tree2.links.new(emission_001_2.outputs[0], mix_shader_2.inputs[2])
        node_tree2.links.new(geometry_2.outputs[6], mix_shader_2.inputs[0])
        node_tree2.links.new(emission_2.outputs[0], mix_shader_2.inputs[1])

    group_001_1 = node_tree1.nodes.new('ShaderNodeGroup')
    if hasattr(group_001_1, 'node_tree'):
        group_001_1.node_tree = bpy.data.node_groups.get('NodeGroup')
    if hasattr(group_001_1, 'color'):
        group_001_1.color = (0.6079999804496765, 0.6079999804496765, 0.6079999804496765)
    if hasattr(group_001_1, 'hide'):
        group_001_1.hide = False
    if hasattr(group_001_1, 'location'):
        group_001_1.location = (340.00006103515625, -100.0)
    if hasattr(group_001_1, 'mute'):
        group_001_1.mute = False
    if hasattr(group_001_1, 'name'):
        group_001_1.name = 'Group.001'
    if hasattr(group_001_1, 'use_custom_color'):
        group_001_1.use_custom_color = False
    if hasattr(group_001_1, 'width'):
        group_001_1.width = 140.0
    group_001_1.inputs[0].default_value = (1.0, 1.0, 1.0)

    math_001_1 = node_tree1.nodes.new('ShaderNodeMath')
    if hasattr(math_001_1, 'color'):
        math_001_1.color = (0.6079999804496765, 0.6079999804496765, 0.6079999804496765)
    if hasattr(math_001_1, 'hide'):
        math_001_1.hide = False
    if hasattr(math_001_1, 'label'):
        math_001_1.label = 'x5'
    if hasattr(math_001_1, 'location'):
        math_001_1.location = (-180.0, -160.0)
    if hasattr(math_001_1, 'mute'):
        math_001_1.mute = False
    if hasattr(math_001_1, 'name'):
        math_001_1.name = 'Math.001'
    if hasattr(math_001_1, 'operation'):
        math_001_1.operation = 'DIVIDE'
    if hasattr(math_001_1, 'use_clamp'):
        math_001_1.use_clamp = False
    if hasattr(math_001_1, 'use_custom_color'):
        math_001_1.use_custom_color = False
    if hasattr(math_001_1, 'width'):
        math_001_1.width = 140.0
    math_001_1.inputs[0].default_value = 100.0
    math_001_1.inputs[1].default_value = 5.0
    math_001_1.inputs[2].default_value = 0.0
    math_001_1.outputs[0].default_value = 0.0

    math_002_1 = node_tree1.nodes.new('ShaderNodeMath')
    if hasattr(math_002_1, 'color'):
        math_002_1.color = (0.6079999804496765, 0.6079999804496765, 0.6079999804496765)
    if hasattr(math_002_1, 'hide'):
        math_002_1.hide = False
    if hasattr(math_002_1, 'label'):
        math_002_1.label = 'x10'
    if hasattr(math_002_1, 'location'):
        math_002_1.location = (20.0, -280.0)
    if hasattr(math_002_1, 'mute'):
        math_002_1.mute = False
    if hasattr(math_002_1, 'name'):
        math_002_1.name = 'Math.002'
    if hasattr(math_002_1, 'operation'):
        math_002_1.operation = 'DIVIDE'
    if hasattr(math_002_1, 'use_clamp'):
        math_002_1.use_clamp = False
    if hasattr(math_002_1, 'use_custom_color'):
        math_002_1.use_custom_color = False
    if hasattr(math_002_1, 'width'):
        math_002_1.width = 140.0
    math_002_1.inputs[0].default_value = 100.0
    math_002_1.inputs[1].default_value = 2.0
    math_002_1.inputs[2].default_value = 0.0
    math_002_1.outputs[0].default_value = 0.0

    group_002_1 = node_tree1.nodes.new('ShaderNodeGroup')
    if hasattr(group_002_1, 'node_tree'):
        group_002_1.node_tree = bpy.data.node_groups.get('NodeGroup')
    if hasattr(group_002_1, 'color'):
        group_002_1.color = (0.6079999804496765, 0.6079999804496765, 0.6079999804496765)
    if hasattr(group_002_1, 'hide'):
        group_002_1.hide = False
    if hasattr(group_002_1, 'location'):
        group_002_1.location = (340.0, 20.0)
    if hasattr(group_002_1, 'mute'):
        group_002_1.mute = False
    if hasattr(group_002_1, 'name'):
        group_002_1.name = 'Group.002'
    if hasattr(group_002_1, 'use_custom_color'):
        group_002_1.use_custom_color = False
    if hasattr(group_002_1, 'width'):
        group_002_1.width = 140.0
    group_002_1.inputs[0].default_value = (1.0, 1.0, 1.0)

    group_1 = node_tree1.nodes.new('ShaderNodeGroup')
    if hasattr(group_1, 'node_tree'):
        group_1.node_tree = bpy.data.node_groups.get('NodeGroup')
    if hasattr(group_1, 'color'):
        group_1.color = (0.6079999804496765, 0.6079999804496765, 0.6079999804496765)
    if hasattr(group_1, 'hide'):
        group_1.hide = False
    if hasattr(group_1, 'location'):
        group_1.location = (340.00006103515625, -220.0)
    if hasattr(group_1, 'mute'):
        group_1.mute = False
    if hasattr(group_1, 'name'):
        group_1.name = 'Group'
    if hasattr(group_1, 'use_custom_color'):
        group_1.use_custom_color = False
    if hasattr(group_1, 'width'):
        group_1.width = 140.0
    group_1.inputs[0].default_value = (1.0, 1.0, 1.0)

    group_output_1 = node_tree1.nodes.new('NodeGroupOutput')
    if hasattr(group_output_1, 'color'):
        group_output_1.color = (0.6079999804496765, 0.6079999804496765, 0.6079999804496765)
    if hasattr(group_output_1, 'hide'):
        group_output_1.hide = False
    if hasattr(group_output_1, 'is_active_output'):
        group_output_1.is_active_output = True
    if hasattr(group_output_1, 'location'):
        group_output_1.location = (520.0, -79.99996948242188)
    if hasattr(group_output_1, 'mute'):
        group_output_1.mute = False
    if hasattr(group_output_1, 'name'):
        group_output_1.name = 'Group Output'
    if hasattr(group_output_1, 'use_custom_color'):
        group_output_1.use_custom_color = False
    if hasattr(group_output_1, 'width'):
        group_output_1.width = 140.0

    # LINKS
    node_tree1.links.new(group_input_1.outputs[0], math_1.inputs[1])
    node_tree1.links.new(math_001_1.outputs[0], math_002_1.inputs[0])
    node_tree1.links.new(math_002_1.outputs[0], group_1.inputs[0])
    node_tree1.links.new(math_1.outputs[0], math_001_1.inputs[0])
    node_tree1.links.new(math_001_1.outputs[0], group_001_1.inputs[0])
    node_tree1.links.new(math_1.outputs[0], group_002_1.inputs[0])
    node_tree1.links.new(group_002_1.outputs[0], group_output_1.inputs[0])
    node_tree1.links.new(group_001_1.outputs[0], group_output_1.inputs[1])
    node_tree1.links.new(group_1.outputs[0], group_output_1.inputs[2])

group_003_0 = node_tree0.nodes.new('ShaderNodeGroup')
if hasattr(group_003_0, 'node_tree'):
    group_003_0.node_tree = bpy.data.node_groups.get('NodeGroup.001')
if hasattr(group_003_0, 'color'):
    group_003_0.color = (0.6079999804496765, 0.6079999804496765, 0.6079999804496765)
if hasattr(group_003_0, 'hide'):
    group_003_0.hide = False
if hasattr(group_003_0, 'location'):
    group_003_0.location = (200.0, -3.0517578125e-05)
if hasattr(group_003_0, 'mute'):
    group_003_0.mute = False
if hasattr(group_003_0, 'name'):
    group_003_0.name = 'Group.003'
if hasattr(group_003_0, 'use_custom_color'):
    group_003_0.use_custom_color = False
if hasattr(group_003_0, 'width'):
    group_003_0.width = 140.0
group_003_0.inputs[0].default_value = 1.0

cl2_0 = node_tree0.nodes.new('ShaderNodeOutputMaterial')
if hasattr(cl2_0, 'color'):
    cl2_0.color = (0.6079999804496765, 0.6079999804496765, 0.6079999804496765)
if hasattr(cl2_0, 'hide'):
    cl2_0.hide = False
if hasattr(cl2_0, 'is_active_output'):
    cl2_0.is_active_output = False
if hasattr(cl2_0, 'label'):
    cl2_0.label = 'CL2'
if hasattr(cl2_0, 'location'):
    cl2_0.location = (400.0, -3.0517578125e-05)
if hasattr(cl2_0, 'mute'):
    cl2_0.mute = False
if hasattr(cl2_0, 'name'):
    cl2_0.name = 'CL2'
if hasattr(cl2_0, 'target'):
    cl2_0.target = 'ALL'
if hasattr(cl2_0, 'use_custom_color'):
    cl2_0.use_custom_color = False
if hasattr(cl2_0, 'width'):
    cl2_0.width = 140.0
cl2_0.inputs[2].default_value = (0.0, 0.0, 0.0)

cl3_0 = node_tree0.nodes.new('ShaderNodeOutputMaterial')
if hasattr(cl3_0, 'color'):
    cl3_0.color = (0.6079999804496765, 0.6079999804496765, 0.6079999804496765)
if hasattr(cl3_0, 'hide'):
    cl3_0.hide = False
if hasattr(cl3_0, 'is_active_output'):
    cl3_0.is_active_output = False
if hasattr(cl3_0, 'label'):
    cl3_0.label = 'CL3'
if hasattr(cl3_0, 'location'):
    cl3_0.location = (400.0000305175781, -140.0)
if hasattr(cl3_0, 'mute'):
    cl3_0.mute = False
if hasattr(cl3_0, 'name'):
    cl3_0.name = 'CL3'
if hasattr(cl3_0, 'target'):
    cl3_0.target = 'ALL'
if hasattr(cl3_0, 'use_custom_color'):
    cl3_0.use_custom_color = False
if hasattr(cl3_0, 'width'):
    cl3_0.width = 140.0
cl3_0.inputs[2].default_value = (0.0, 0.0, 0.0)

cl1_0 = node_tree0.nodes.new('ShaderNodeOutputMaterial')
if hasattr(cl1_0, 'color'):
    cl1_0.color = (0.6079999804496765, 0.6079999804496765, 0.6079999804496765)
if hasattr(cl1_0, 'hide'):
    cl1_0.hide = False
if hasattr(cl1_0, 'is_active_output'):
    cl1_0.is_active_output = True
if hasattr(cl1_0, 'label'):
    cl1_0.label = 'CL1'
if hasattr(cl1_0, 'location'):
    cl1_0.location = (400.0000305175781, 140.0)
if hasattr(cl1_0, 'mute'):
    cl1_0.mute = False
if hasattr(cl1_0, 'name'):
    cl1_0.name = 'CL1'
if hasattr(cl1_0, 'target'):
    cl1_0.target = 'ALL'
if hasattr(cl1_0, 'use_custom_color'):
    cl1_0.use_custom_color = False
if hasattr(cl1_0, 'width'):
    cl1_0.width = 140.0
cl1_0.inputs[2].default_value = (0.0, 0.0, 0.0)

# LINKS
node_tree0.links.new(value_0.outputs[0], group_003_0.inputs[0])
node_tree0.links.new(group_003_0.outputs[0], cl1_0.inputs[0])
node_tree0.links.new(group_003_0.outputs[1], cl2_0.inputs[0])
node_tree0.links.new(group_003_0.outputs[2], cl3_0.inputs[0])

# TO ACTIVE
selected_objects = (obj for obj in bpy.data.objects if obj.select_get())
for obj in selected_objects:
    obj.active_material = r2_contourline
