# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "PETRA Extended",
    "author" : "Valentin Grimaud", 
    "description" : "Protocole Employing Three dimensional Representations in Archaeology",
    "blender" : (3, 2, 0),
    "version" : (0, 4, 0),
    "location" : "View3D > Sidebar > New Tab",
    "waring" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "Render" 
}


import bpy
import bpy.utils.previews
from petra_blender_addon.blendertools import remove_link


addon_keymaps = {}
_icons = None


def sna_add_to_petra_pt_initial_setup_5B9D4(self, context):
    if not (False):
        layout = self.layout
        col_5869D = layout.column(heading='', align=True)
        col_5869D.alert = False
        col_5869D.enabled = True
        col_5869D.active = True
        col_5869D.use_property_split = False
        col_5869D.use_property_decorate = False
        col_5869D.scale_x = 1.0
        col_5869D.scale_y = 1.0
        col_5869D.alignment = 'Expand'.upper()
        col_5869D.label(text='Mesh Resolution:', icon_value=0)
        col_5869D.prop(bpy.context.view_layer.objects.active.modifiers['GeometryNodes'], '["Input_2"]', text='', icon_value=0, emboss=True)


def sna_add_to_petra_pt_initial_setup_D7B75(self, context):
    if not (False):
        layout = self.layout
        op = layout.operator('wm.save_mainfile', text='Save your Blender file first! ', icon_value=0, emboss=True, depress=False)


class SNA_OT_Rl_C1_Prv_7F7Cc(bpy.types.Operator):
    bl_idname = "sna.rl_c1_prv_7f7cc"
    bl_label = "RL_C1_PRV"
    bl_description = "Configuration to see the color (from vertex color)"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        ################################################################
        # Setting everything properly to render any layer of information
        # (in case a user change something)
        ################################################################
        import os
        C = bpy.context
        D = bpy.data
        S = D.scenes["Scene"]
        obj = C.object
        nodetree = C.scene.node_tree
        # Don't render `Reference Sphere`
        D.objects["Reference Sphere"].hide_render = True
        ## Render transparent background
        C.scene.render.film_transparent = True
        ## Color management
        C.scene.view_settings.view_transform = "Standard"
        # Hide in render
        D.objects["Reference Sphere"].hide_render = True
        D.objects["Framing Box"].hide_render = True
        # Deactivate Ambient Occlusion
        C.scene.eevee.use_gtao = False
        # Hide GeoNode modifier
        selected_object = C.selected_objects[0]
        selected_object.modifiers["GeometryNodes"].show_render = False
        # Slot management
        mat = bpy.data.materials.get("c1_prv")
            # Determine whether there are slots to work with
        if len(obj.material_slots) > 0:
            # Assign the material to each slot
            for c, slot in enumerate(obj.material_slots):
                obj.material_slots[c].material = mat
        else:
            # In case there is no material, append the Demo material
            obj.data.materials.append(mat)
        # /////////////////////
        # Configure Compositor
        # Get reference
        node_RL = nodetree.nodes["Render Layers"]
        node_PETrA = nodetree.nodes["PETrA"]
        node_PETrA_Input = node_PETrA.node_tree.nodes["Group Input"]
        node_C1 = node_PETrA.node_tree.nodes["C1_color"]
        node_H = node_PETrA.node_tree.nodes["H_covering"]
        node_L1 = node_PETrA.node_tree.nodes["L1_AO"]
        node_R1 = node_PETrA.node_tree.nodes["R1_shading"]
        node_R2 = node_PETrA.node_tree.nodes["R2_contourLine"]
        node_R3 = node_PETrA.node_tree.nodes["R3_deviationMap"]
        node_R4 = node_PETrA.node_tree.nodes["R4_pointiness"]
        node_R5 = node_PETrA.node_tree.nodes["R5_aspect"]
        node_R6 = node_PETrA.node_tree.nodes["R6_slope"]
        for i in range(10):  # loops through "i = 0 ... 9".
            remove_link(node_RL.outputs[0], node_PETrA.inputs[i])
        remove_link(node_PETrA_Input.outputs[0], node_C1.inputs[0])
        remove_link(node_PETrA_Input.outputs[0], node_C1.inputs[1])
        # Get reference
        C = bpy.context
        D = bpy.data
        S = D.scenes["Scene"]
        nodetree = C.scene.node_tree
        node_RL = nodetree.nodes["Render Layers"]
        node_PETrA = nodetree.nodes["PETrA"]
        node_PETrA_Input = node_PETrA.node_tree.nodes["Group Input"]
        node_PETrA_nodetree = node_PETrA.node_tree
        node_C1 = node_PETrA.node_tree.nodes["C1_color"]
        # Select render Engine
        C.scene.render.engine = "BLENDER_EEVEE"
        # Apply material
        material = D.materials["C1_PRV"]
        selected_object = C.selected_objects[0]
        selected_object.material_slots[0].material = material
        D.materials["C1_PRV"].node_tree.nodes["inputColor"].layer_name = "Col"
        # Apply material to every selected object
        bpy.ops.object.make_links_data(type='MATERIAL')
        # Configure Compositor
        nodetree.links.new(node_RL.outputs[0], node_PETrA.inputs[0])
        node_PETrA_nodetree.links.new(node_PETrA_Input.outputs[0], node_C1.inputs[1])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Rl_H1_36085(bpy.types.Operator):
    bl_idname = "sna.rl_h1_36085"
    bl_label = "RL_H1"
    bl_description = "Configuration to generate masks"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        ################################################################
        # Setting everything properly to render any layer of information
        # (in case a user change something)
        ################################################################
        import os
        C = bpy.context
        D = bpy.data
        S = D.scenes["Scene"]
        obj = C.object
        nodetree = C.scene.node_tree
        # Don't render `Reference Sphere`
        D.objects["Reference Sphere"].hide_render = True
        ## Render transparent background
        C.scene.render.film_transparent = True
        ## Color management
        C.scene.view_settings.view_transform = "Standard"
        # Hide in render
        D.objects["Reference Sphere"].hide_render = True
        D.objects["Framing Box"].hide_render = True
        # Deactivate Ambient Occlusion
        C.scene.eevee.use_gtao = False
        # Hide GeoNode modifier
        selected_object = C.selected_objects[0]
        selected_object.modifiers["GeometryNodes"].show_render = False
        # Slot management
        mat = bpy.data.materials.get("c1_prv")
            # Determine whether there are slots to work with
        if len(obj.material_slots) > 0:
            # Assign the material to each slot
            for c, slot in enumerate(obj.material_slots):
                obj.material_slots[c].material = mat
        else:
            # In case there is no material, append the Demo material
            obj.data.materials.append(mat)
        # /////////////////////
        # Configure Compositor
        # Get reference
        node_RL = nodetree.nodes["Render Layers"]
        node_PETrA = nodetree.nodes["PETrA"]
        node_PETrA_Input = node_PETrA.node_tree.nodes["Group Input"]
        node_C1 = node_PETrA.node_tree.nodes["C1_color"]
        node_H = node_PETrA.node_tree.nodes["H_covering"]
        node_L1 = node_PETrA.node_tree.nodes["L1_AO"]
        node_R1 = node_PETrA.node_tree.nodes["R1_shading"]
        node_R2 = node_PETrA.node_tree.nodes["R2_contourLine"]
        node_R3 = node_PETrA.node_tree.nodes["R3_deviationMap"]
        node_R4 = node_PETrA.node_tree.nodes["R4_pointiness"]
        node_R5 = node_PETrA.node_tree.nodes["R5_aspect"]
        node_R6 = node_PETrA.node_tree.nodes["R6_slope"]
        for i in range(10):  # loops through "i = 0 ... 9".
            remove_link(node_RL.outputs[0], node_PETrA.inputs[i])
        remove_link(node_PETrA_Input.outputs[0], node_C1.inputs[0])
        remove_link(node_PETrA_Input.outputs[0], node_C1.inputs[1])
        # Get reference
        C = bpy.context
        D = bpy.data
        S = D.scenes["Scene"]
        nodetree = C.scene.node_tree
        node_RL = S.node_tree.nodes["Render Layers"]
        node_PETrA = S.node_tree.nodes["PETrA"]
        # Select render Engine
        C.scene.render.engine = "BLENDER_EEVEE"
        # Apply material to selected objects
        material = D.materials["H1_Masks"]
        selected_object = C.selected_objects[0]
        selected_object.material_slots[0].material = material
        # Apply material to every selected object
        bpy.ops.object.make_links_data(type='MATERIAL')
        # Configure Compositor
        nodetree.links.new(node_RL.outputs[0], node_PETrA.inputs[1])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Rl_H2_B6C13(bpy.types.Operator):
    bl_idname = "sna.rl_h2_b6c13"
    bl_label = "RL_H2"
    bl_description = "Configuration to generate contours"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        ################################################################
        # Setting everything properly to render any layer of information
        # (in case a user change something)
        ################################################################
        import os
        C = bpy.context
        D = bpy.data
        S = D.scenes["Scene"]
        obj = C.object
        nodetree = C.scene.node_tree
        # Don't render `Reference Sphere`
        D.objects["Reference Sphere"].hide_render = True
        ## Render transparent background
        C.scene.render.film_transparent = True
        ## Color management
        C.scene.view_settings.view_transform = "Standard"
        # Hide in render
        D.objects["Reference Sphere"].hide_render = True
        D.objects["Framing Box"].hide_render = True
        # Deactivate Ambient Occlusion
        C.scene.eevee.use_gtao = False
        # Hide GeoNode modifier
        selected_object = C.selected_objects[0]
        selected_object.modifiers["GeometryNodes"].show_render = False
        # Slot management
        mat = bpy.data.materials.get("c1_prv")
            # Determine whether there are slots to work with
        if len(obj.material_slots) > 0:
            # Assign the material to each slot
            for c, slot in enumerate(obj.material_slots):
                obj.material_slots[c].material = mat
        else:
            # In case there is no material, append the Demo material
            obj.data.materials.append(mat)
        # /////////////////////
        # Configure Compositor
        # Get reference
        node_RL = nodetree.nodes["Render Layers"]
        node_PETrA = nodetree.nodes["PETrA"]
        node_PETrA_Input = node_PETrA.node_tree.nodes["Group Input"]
        node_C1 = node_PETrA.node_tree.nodes["C1_color"]
        node_H = node_PETrA.node_tree.nodes["H_covering"]
        node_L1 = node_PETrA.node_tree.nodes["L1_AO"]
        node_R1 = node_PETrA.node_tree.nodes["R1_shading"]
        node_R2 = node_PETrA.node_tree.nodes["R2_contourLine"]
        node_R3 = node_PETrA.node_tree.nodes["R3_deviationMap"]
        node_R4 = node_PETrA.node_tree.nodes["R4_pointiness"]
        node_R5 = node_PETrA.node_tree.nodes["R5_aspect"]
        node_R6 = node_PETrA.node_tree.nodes["R6_slope"]
        for i in range(10):  # loops through "i = 0 ... 9".
            remove_link(node_RL.outputs[0], node_PETrA.inputs[i])
        remove_link(node_PETrA_Input.outputs[0], node_C1.inputs[0])
        remove_link(node_PETrA_Input.outputs[0], node_C1.inputs[1])
        # Get reference
        C = bpy.context
        D = bpy.data
        S = D.scenes["Scene"]
        nodetree = C.scene.node_tree
        node_RL = S.node_tree.nodes["Render Layers"]
        node_PETrA = S.node_tree.nodes["PETrA"]
        # Select render Engine
        C.scene.render.engine = "BLENDER_EEVEE"
        # Apply material to selected objects
        material = D.materials["H2_OBN"]
        selected_object = C.selected_objects[0]
        selected_object.material_slots[0].material = material
        # Apply material to every selected object
        bpy.ops.object.make_links_data(type='MATERIAL')
        # Configure Compositor
        nodetree.links.new(node_RL.outputs[0], node_PETrA.inputs[2])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Rl_L1_060E0(bpy.types.Operator):
    bl_idname = "sna.rl_l1_060e0"
    bl_label = "RL_L1"
    bl_description = "Configuration to generate ambient occlusion"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        ################################################################
        # Setting everything properly to render any layer of information
        # (in case a user change something)
        ################################################################
        import os
        C = bpy.context
        D = bpy.data
        S = D.scenes["Scene"]
        obj = C.object
        nodetree = C.scene.node_tree
        # Don't render `Reference Sphere`
        D.objects["Reference Sphere"].hide_render = True
        ## Render transparent background
        C.scene.render.film_transparent = True
        ## Color management
        C.scene.view_settings.view_transform = "Standard"
        # Hide in render
        D.objects["Reference Sphere"].hide_render = True
        D.objects["Framing Box"].hide_render = True
        # Deactivate Ambient Occlusion
        C.scene.eevee.use_gtao = False
        # Hide GeoNode modifier
        selected_object = C.selected_objects[0]
        selected_object.modifiers["GeometryNodes"].show_render = False
        # Slot management
        mat = bpy.data.materials.get("c1_prv")
            # Determine whether there are slots to work with
        if len(obj.material_slots) > 0:
            # Assign the material to each slot
            for c, slot in enumerate(obj.material_slots):
                obj.material_slots[c].material = mat
        else:
            # In case there is no material, append the Demo material
            obj.data.materials.append(mat)
        # /////////////////////
        # Configure Compositor
        # Get reference
        node_RL = nodetree.nodes["Render Layers"]
        node_PETrA = nodetree.nodes["PETrA"]
        node_PETrA_Input = node_PETrA.node_tree.nodes["Group Input"]
        node_C1 = node_PETrA.node_tree.nodes["C1_color"]
        node_H = node_PETrA.node_tree.nodes["H_covering"]
        node_L1 = node_PETrA.node_tree.nodes["L1_AO"]
        node_R1 = node_PETrA.node_tree.nodes["R1_shading"]
        node_R2 = node_PETrA.node_tree.nodes["R2_contourLine"]
        node_R3 = node_PETrA.node_tree.nodes["R3_deviationMap"]
        node_R4 = node_PETrA.node_tree.nodes["R4_pointiness"]
        node_R5 = node_PETrA.node_tree.nodes["R5_aspect"]
        node_R6 = node_PETrA.node_tree.nodes["R6_slope"]
        for i in range(10):  # loops through "i = 0 ... 9".
            remove_link(node_RL.outputs[0], node_PETrA.inputs[i])
        remove_link(node_PETrA_Input.outputs[0], node_C1.inputs[0])
        remove_link(node_PETrA_Input.outputs[0], node_C1.inputs[1])
        # Get reference
        C = bpy.context
        D = bpy.data
        S = D.scenes["Scene"]
        nodetree = C.scene.node_tree
        node_RL = S.node_tree.nodes["Render Layers"]
        node_PETrA = S.node_tree.nodes["PETrA"]
        # Select render Engine
        C.scene.render.engine = "BLENDER_EEVEE"
        # Activate Ambient Occlusion
        C.scene.eevee.use_gtao = True
        # Ambient Occlusion Distance
        C.scene.eevee.gtao_distance = 5
        # Ambient Occlusion Quality
        C.scene.eevee.gtao_quality = 1
        # Apply material to selected objects
        material = D.materials["L1_AO"]
        selected_object = C.selected_objects[0]
        selected_object.material_slots[0].material = material
        # Apply material to every selected object
        bpy.ops.object.make_links_data(type='MATERIAL')
        # Configure Compositor
        nodetree.links.new(node_RL.outputs[0], node_PETrA.inputs[3])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Rl_R1_D5Aaf(bpy.types.Operator):
    bl_idname = "sna.rl_r1_d5aaf"
    bl_label = "RL_R1"
    bl_description = "Configuration to generate shadings"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        ################################################################
        # Setting everything properly to render any layer of information
        # (in case a user change something)
        ################################################################
        import os
        C = bpy.context
        D = bpy.data
        S = D.scenes["Scene"]
        obj = C.object
        nodetree = C.scene.node_tree
        # Don't render `Reference Sphere`
        D.objects["Reference Sphere"].hide_render = True
        ## Render transparent background
        C.scene.render.film_transparent = True
        ## Color management
        C.scene.view_settings.view_transform = "Standard"
        # Hide in render
        D.objects["Reference Sphere"].hide_render = True
        D.objects["Framing Box"].hide_render = True
        # Deactivate Ambient Occlusion
        C.scene.eevee.use_gtao = False
        # Hide GeoNode modifier
        selected_object = C.selected_objects[0]
        selected_object.modifiers["GeometryNodes"].show_render = False
        # Slot management
        mat = bpy.data.materials.get("c1_prv")
            # Determine whether there are slots to work with
        if len(obj.material_slots) > 0:
            # Assign the material to each slot
            for c, slot in enumerate(obj.material_slots):
                obj.material_slots[c].material = mat
        else:
            # In case there is no material, append the Demo material
            obj.data.materials.append(mat)
        # /////////////////////
        # Configure Compositor
        # Get reference
        node_RL = nodetree.nodes["Render Layers"]
        node_PETrA = nodetree.nodes["PETrA"]
        node_PETrA_Input = node_PETrA.node_tree.nodes["Group Input"]
        node_C1 = node_PETrA.node_tree.nodes["C1_color"]
        node_H = node_PETrA.node_tree.nodes["H_covering"]
        node_L1 = node_PETrA.node_tree.nodes["L1_AO"]
        node_R1 = node_PETrA.node_tree.nodes["R1_shading"]
        node_R2 = node_PETrA.node_tree.nodes["R2_contourLine"]
        node_R3 = node_PETrA.node_tree.nodes["R3_deviationMap"]
        node_R4 = node_PETrA.node_tree.nodes["R4_pointiness"]
        node_R5 = node_PETrA.node_tree.nodes["R5_aspect"]
        node_R6 = node_PETrA.node_tree.nodes["R6_slope"]
        for i in range(10):  # loops through "i = 0 ... 9".
            remove_link(node_RL.outputs[0], node_PETrA.inputs[i])
        remove_link(node_PETrA_Input.outputs[0], node_C1.inputs[0])
        remove_link(node_PETrA_Input.outputs[0], node_C1.inputs[1])
        # Get reference
        C = bpy.context
        D = bpy.data
        S = D.scenes["Scene"]
        nodetree = C.scene.node_tree
        node_RL = S.node_tree.nodes["Render Layers"]
        node_PETrA = S.node_tree.nodes["PETrA"]
        # Select render Engine
        C.scene.render.engine = "BLENDER_EEVEE"
        # Apply material to selected objects
        material = D.materials["R1_NMC"]
        selected_object = C.selected_objects[0]
        selected_object.material_slots[0].material = material
        refSphere = D.objects["Reference Sphere"]
        refSphere.material_slots[0].material = material
        # Apply material to every selected object
        bpy.ops.object.make_links_data(type='MATERIAL')
        # Render `Reference Sphere`
        D.objects["Reference Sphere"].hide_render = False
        # Configure Compositor
        nodetree.links.new(node_RL.outputs[0], node_PETrA.inputs[4])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Rl_R2_Cl2_84431(bpy.types.Operator):
    bl_idname = "sna.rl_r2_cl2_84431"
    bl_label = "RL_R2_CL2"
    bl_description = "Configuration to generate contour lines (x5)"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        ################################################################
        # Setting everything properly to render any layer of information
        # (in case a user change something)
        ################################################################
        import os
        C = bpy.context
        D = bpy.data
        S = D.scenes["Scene"]
        obj = C.object
        nodetree = C.scene.node_tree
        # Don't render `Reference Sphere`
        D.objects["Reference Sphere"].hide_render = True
        ## Render transparent background
        C.scene.render.film_transparent = True
        ## Color management
        C.scene.view_settings.view_transform = "Standard"
        # Hide in render
        D.objects["Reference Sphere"].hide_render = True
        D.objects["Framing Box"].hide_render = True
        # Deactivate Ambient Occlusion
        C.scene.eevee.use_gtao = False
        # Hide GeoNode modifier
        selected_object = C.selected_objects[0]
        selected_object.modifiers["GeometryNodes"].show_render = False
        # Slot management
        mat = bpy.data.materials.get("c1_prv")
            # Determine whether there are slots to work with
        if len(obj.material_slots) > 0:
            # Assign the material to each slot
            for c, slot in enumerate(obj.material_slots):
                obj.material_slots[c].material = mat
        else:
            # In case there is no material, append the Demo material
            obj.data.materials.append(mat)
        # /////////////////////
        # Configure Compositor
        # Get reference
        node_RL = nodetree.nodes["Render Layers"]
        node_PETrA = nodetree.nodes["PETrA"]
        node_PETrA_Input = node_PETrA.node_tree.nodes["Group Input"]
        node_C1 = node_PETrA.node_tree.nodes["C1_color"]
        node_H = node_PETrA.node_tree.nodes["H_covering"]
        node_L1 = node_PETrA.node_tree.nodes["L1_AO"]
        node_R1 = node_PETrA.node_tree.nodes["R1_shading"]
        node_R2 = node_PETrA.node_tree.nodes["R2_contourLine"]
        node_R3 = node_PETrA.node_tree.nodes["R3_deviationMap"]
        node_R4 = node_PETrA.node_tree.nodes["R4_pointiness"]
        node_R5 = node_PETrA.node_tree.nodes["R5_aspect"]
        node_R6 = node_PETrA.node_tree.nodes["R6_slope"]
        for i in range(10):  # loops through "i = 0 ... 9".
            remove_link(node_RL.outputs[0], node_PETrA.inputs[i])
        remove_link(node_PETrA_Input.outputs[0], node_C1.inputs[0])
        remove_link(node_PETrA_Input.outputs[0], node_C1.inputs[1])
        from petra_blender_addon import popup
        # Get reference
        C = bpy.context
        D = bpy.data
        S = D.scenes["Scene"]
        nodetree = C.scene.node_tree
        node_RL = S.node_tree.nodes["Render Layers"]
        node_PETrA = S.node_tree.nodes["PETrA"]
        node_R2 = node_PETrA.node_tree.nodes["R2_contourLine"]
        node_R2_nodetree = node_R2.node_tree
        node_R2b = node_R2.node_tree.nodes["ColorRamp"]
        node_R2z = node_R2.node_tree.nodes["File Output"]
        node_R2_tmp = bpy.data.node_groups["R2: Contour Lines"].nodes["tmp_CL"]
        # Select render Engine
        C.scene.render.engine = "BLENDER_EEVEE"
        # Apply material to selected objects
        material = D.materials["R2_CL"]
        selected_object = C.selected_objects[0]
        selected_object.material_slots[0].material = material
        # Apply material to every selected object
        bpy.ops.object.make_links_data(type='MATERIAL')
        # Apply the right spacing
        D.materials["R2_CL"].node_tree.nodes["math1"].mute = False
        D.materials["R2_CL"].node_tree.nodes["math2"].mute = False
        D.materials["R2_CL"].node_tree.nodes["math3"].mute = True
        # Output name
        node_R2z.file_slots[0].path = "Cam-##_R2_CL2"
        node_R2_tmp.file_slots[0].path = "Cam-##_R2_CL2"
        # Configure Compositor
        nodetree.links.new(node_RL.outputs[0], node_PETrA.inputs[5])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Rl_R2_Cl3_D27E4(bpy.types.Operator):
    bl_idname = "sna.rl_r2_cl3_d27e4"
    bl_label = "RL_R2_CL3"
    bl_description = "Configuration to generate contour lines (x10)"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        ################################################################
        # Setting everything properly to render any layer of information
        # (in case a user change something)
        ################################################################
        import os
        C = bpy.context
        D = bpy.data
        S = D.scenes["Scene"]
        obj = C.object
        nodetree = C.scene.node_tree
        # Don't render `Reference Sphere`
        D.objects["Reference Sphere"].hide_render = True
        ## Render transparent background
        C.scene.render.film_transparent = True
        ## Color management
        C.scene.view_settings.view_transform = "Standard"
        # Hide in render
        D.objects["Reference Sphere"].hide_render = True
        D.objects["Framing Box"].hide_render = True
        # Deactivate Ambient Occlusion
        C.scene.eevee.use_gtao = False
        # Hide GeoNode modifier
        selected_object = C.selected_objects[0]
        selected_object.modifiers["GeometryNodes"].show_render = False
        # Slot management
        mat = bpy.data.materials.get("c1_prv")
            # Determine whether there are slots to work with
        if len(obj.material_slots) > 0:
            # Assign the material to each slot
            for c, slot in enumerate(obj.material_slots):
                obj.material_slots[c].material = mat
        else:
            # In case there is no material, append the Demo material
            obj.data.materials.append(mat)
        # /////////////////////
        # Configure Compositor
        # Get reference
        node_RL = nodetree.nodes["Render Layers"]
        node_PETrA = nodetree.nodes["PETrA"]
        node_PETrA_Input = node_PETrA.node_tree.nodes["Group Input"]
        node_C1 = node_PETrA.node_tree.nodes["C1_color"]
        node_H = node_PETrA.node_tree.nodes["H_covering"]
        node_L1 = node_PETrA.node_tree.nodes["L1_AO"]
        node_R1 = node_PETrA.node_tree.nodes["R1_shading"]
        node_R2 = node_PETrA.node_tree.nodes["R2_contourLine"]
        node_R3 = node_PETrA.node_tree.nodes["R3_deviationMap"]
        node_R4 = node_PETrA.node_tree.nodes["R4_pointiness"]
        node_R5 = node_PETrA.node_tree.nodes["R5_aspect"]
        node_R6 = node_PETrA.node_tree.nodes["R6_slope"]
        for i in range(10):  # loops through "i = 0 ... 9".
            remove_link(node_RL.outputs[0], node_PETrA.inputs[i])
        remove_link(node_PETrA_Input.outputs[0], node_C1.inputs[0])
        remove_link(node_PETrA_Input.outputs[0], node_C1.inputs[1])
        from petra_blender_addon import popup
        # Get reference
        C = bpy.context
        D = bpy.data
        S = D.scenes["Scene"]
        nodetree = C.scene.node_tree
        node_RL = S.node_tree.nodes["Render Layers"]
        node_PETrA = S.node_tree.nodes["PETrA"]
        node_R2 = node_PETrA.node_tree.nodes["R2_contourLine"]
        node_R2_nodetree = node_R2.node_tree
        node_R2b = node_R2.node_tree.nodes["ColorRamp"]
        node_R2z = node_R2.node_tree.nodes["File Output"]
        node_R2_tmp = bpy.data.node_groups["R2: Contour Lines"].nodes["tmp_CL"]
        # Select render Engine
        C.scene.render.engine = "BLENDER_EEVEE"
        # Apply material to selected objects
        material = D.materials["R2_CL"]
        selected_object = C.selected_objects[0]
        selected_object.material_slots[0].material = material
        # Apply material to every selected object
        bpy.ops.object.make_links_data(type='MATERIAL')
        # Apply the right spacing
        D.materials["R2_CL"].node_tree.nodes["math1"].mute = False
        D.materials["R2_CL"].node_tree.nodes["math2"].mute = False
        D.materials["R2_CL"].node_tree.nodes["math3"].mute = False
        # Output name
        node_R2z.file_slots[0].path = "Cam-##_R2_CL3"
        node_R2_tmp.file_slots[0].path = "Cam-##_R2_CL3"
        # Configure Compositor
        nodetree.links.new(node_RL.outputs[0], node_PETrA.inputs[5])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Rl_R2_Cl1_05184(bpy.types.Operator):
    bl_idname = "sna.rl_r2_cl1_05184"
    bl_label = "RL_R2_CL1"
    bl_description = "Configuration to generate contour lines (x1)"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        ################################################################
        # Setting everything properly to render any layer of information
        # (in case a user change something)
        ################################################################
        import os
        C = bpy.context
        D = bpy.data
        S = D.scenes["Scene"]
        obj = C.object
        nodetree = C.scene.node_tree
        # Don't render `Reference Sphere`
        D.objects["Reference Sphere"].hide_render = True
        ## Render transparent background
        C.scene.render.film_transparent = True
        ## Color management
        C.scene.view_settings.view_transform = "Standard"
        # Hide in render
        D.objects["Reference Sphere"].hide_render = True
        D.objects["Framing Box"].hide_render = True
        # Deactivate Ambient Occlusion
        C.scene.eevee.use_gtao = False
        # Hide GeoNode modifier
        selected_object = C.selected_objects[0]
        selected_object.modifiers["GeometryNodes"].show_render = False
        # Slot management
        mat = bpy.data.materials.get("c1_prv")
            # Determine whether there are slots to work with
        if len(obj.material_slots) > 0:
            # Assign the material to each slot
            for c, slot in enumerate(obj.material_slots):
                obj.material_slots[c].material = mat
        else:
            # In case there is no material, append the Demo material
            obj.data.materials.append(mat)
        # /////////////////////
        # Configure Compositor
        # Get reference
        node_RL = nodetree.nodes["Render Layers"]
        node_PETrA = nodetree.nodes["PETrA"]
        node_PETrA_Input = node_PETrA.node_tree.nodes["Group Input"]
        node_C1 = node_PETrA.node_tree.nodes["C1_color"]
        node_H = node_PETrA.node_tree.nodes["H_covering"]
        node_L1 = node_PETrA.node_tree.nodes["L1_AO"]
        node_R1 = node_PETrA.node_tree.nodes["R1_shading"]
        node_R2 = node_PETrA.node_tree.nodes["R2_contourLine"]
        node_R3 = node_PETrA.node_tree.nodes["R3_deviationMap"]
        node_R4 = node_PETrA.node_tree.nodes["R4_pointiness"]
        node_R5 = node_PETrA.node_tree.nodes["R5_aspect"]
        node_R6 = node_PETrA.node_tree.nodes["R6_slope"]
        for i in range(10):  # loops through "i = 0 ... 9".
            remove_link(node_RL.outputs[0], node_PETrA.inputs[i])
        remove_link(node_PETrA_Input.outputs[0], node_C1.inputs[0])
        remove_link(node_PETrA_Input.outputs[0], node_C1.inputs[1])
        from petra_blender_addon import popup
        # Get reference
        C = bpy.context
        D = bpy.data
        S = D.scenes["Scene"]
        nodetree = C.scene.node_tree
        node_RL = S.node_tree.nodes["Render Layers"]
        node_PETrA = S.node_tree.nodes["PETrA"]
        node_R2 = node_PETrA.node_tree.nodes["R2_contourLine"]
        node_R2_nodetree = node_R2.node_tree
        node_R2b = node_R2.node_tree.nodes["ColorRamp"]
        node_R2z = node_R2.node_tree.nodes["File Output"]
        node_R2_tmp = bpy.data.node_groups["R2: Contour Lines"].nodes["tmp_CL"]
        # Select render Engine
        C.scene.render.engine = "BLENDER_EEVEE"
        # Apply material to selected objects
        material = D.materials["R2_CL"]
        selected_object = C.selected_objects[0]
        selected_object.material_slots[0].material = material
        # Apply material to every selected object
        bpy.ops.object.make_links_data(type='MATERIAL')
        # Apply the right spacing
        D.materials["R2_CL"].node_tree.nodes["math1"].mute = False
        D.materials["R2_CL"].node_tree.nodes["math2"].mute = True
        D.materials["R2_CL"].node_tree.nodes["math3"].mute = True
        # Output name
        node_R2z.file_slots[0].path = "Cam-##_R2_CL1"
        node_R2_tmp.file_slots[0].path = "Cam-##_R2_CL1"
        # Configure Compositor
        nodetree.links.new(node_RL.outputs[0], node_PETrA.inputs[5])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Rl_R4_Po2_7Fcd0(bpy.types.Operator):
    bl_idname = "sna.rl_r4_po2_7fcd0"
    bl_label = "RL_R4_PO2"
    bl_description = "Configuration to generate pointiness (resolution = 1/2)"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        ################################################################
        # Setting everything properly to render any layer of information
        # (in case a user change something)
        ################################################################
        import os
        C = bpy.context
        D = bpy.data
        S = D.scenes["Scene"]
        obj = C.object
        nodetree = C.scene.node_tree
        # Don't render `Reference Sphere`
        D.objects["Reference Sphere"].hide_render = True
        ## Render transparent background
        C.scene.render.film_transparent = True
        ## Color management
        C.scene.view_settings.view_transform = "Standard"
        # Hide in render
        D.objects["Reference Sphere"].hide_render = True
        D.objects["Framing Box"].hide_render = True
        # Deactivate Ambient Occlusion
        C.scene.eevee.use_gtao = False
        # Hide GeoNode modifier
        selected_object = C.selected_objects[0]
        selected_object.modifiers["GeometryNodes"].show_render = False
        # Slot management
        mat = bpy.data.materials.get("c1_prv")
            # Determine whether there are slots to work with
        if len(obj.material_slots) > 0:
            # Assign the material to each slot
            for c, slot in enumerate(obj.material_slots):
                obj.material_slots[c].material = mat
        else:
            # In case there is no material, append the Demo material
            obj.data.materials.append(mat)
        # /////////////////////
        # Configure Compositor
        # Get reference
        node_RL = nodetree.nodes["Render Layers"]
        node_PETrA = nodetree.nodes["PETrA"]
        node_PETrA_Input = node_PETrA.node_tree.nodes["Group Input"]
        node_C1 = node_PETrA.node_tree.nodes["C1_color"]
        node_H = node_PETrA.node_tree.nodes["H_covering"]
        node_L1 = node_PETrA.node_tree.nodes["L1_AO"]
        node_R1 = node_PETrA.node_tree.nodes["R1_shading"]
        node_R2 = node_PETrA.node_tree.nodes["R2_contourLine"]
        node_R3 = node_PETrA.node_tree.nodes["R3_deviationMap"]
        node_R4 = node_PETrA.node_tree.nodes["R4_pointiness"]
        node_R5 = node_PETrA.node_tree.nodes["R5_aspect"]
        node_R6 = node_PETrA.node_tree.nodes["R6_slope"]
        for i in range(10):  # loops through "i = 0 ... 9".
            remove_link(node_RL.outputs[0], node_PETrA.inputs[i])
        remove_link(node_PETrA_Input.outputs[0], node_C1.inputs[0])
        remove_link(node_PETrA_Input.outputs[0], node_C1.inputs[1])
        from petra_blender_addon import popup
        # Get reference
        C = bpy.context
        D = bpy.data
        S = D.scenes["Scene"]
        nodetree = S.node_tree
        node_RL = nodetree.nodes["Render Layers"]
        node_PETrA = nodetree.nodes["PETrA"]
        node_PETrA_Input = node_PETrA.node_tree.nodes["Group Input"]
        node_R4 = node_PETrA.node_tree.nodes["R4_pointiness"]
        gn = D.node_groups["mergeByDistance"] # this is Geometry Nodes
        # Select render Engine
        C.scene.render.engine = "CYCLES"
        # Apply material to selected objects
        material = D.materials["R4_POI"]
        selected_object = C.selected_objects[0]
        selected_object.material_slots[0].material = material
        # Apply material to every selected object
        bpy.ops.object.make_links_data(type='MATERIAL')
        # Render GeoNode modifyer
        selected_object.modifiers["GeometryNodes"].show_render = True
        # Apply modifier to every selected object
        bpy.ops.object.make_links_data(type='MODIFIERS')
        # Set Mesh Resolution  = 1/2
        math1 = gn.nodes["Math1"]
        math1.mute = False
        math2 = gn.nodes["Math2"]
        math2.mute = True
        # Adjust Output filenames (end with -[ratio])
        node_R4_Output = node_R4.node_tree.nodes["File Output"]
        resolution = selected_object.modifiers["GeometryNodes"]["Input_2"]
        resolution_mm = round(resolution*1000, 6)*2
        pattern = f"Cam-##_R4_POI-{resolution_mm}mm"
        node_R4_Output.file_slots[0].path = pattern
        # Create link
        nodetree.links.new(node_RL.outputs[0], node_PETrA.inputs[7])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Rl_R4_Po3_Cefb6(bpy.types.Operator):
    bl_idname = "sna.rl_r4_po3_cefb6"
    bl_label = "RL_R4_PO3"
    bl_description = "Configuration to generate pointiness (resolution = 1/3)"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        ################################################################
        # Setting everything properly to render any layer of information
        # (in case a user change something)
        ################################################################
        import os
        C = bpy.context
        D = bpy.data
        S = D.scenes["Scene"]
        obj = C.object
        nodetree = C.scene.node_tree
        # Don't render `Reference Sphere`
        D.objects["Reference Sphere"].hide_render = True
        ## Render transparent background
        C.scene.render.film_transparent = True
        ## Color management
        C.scene.view_settings.view_transform = "Standard"
        # Hide in render
        D.objects["Reference Sphere"].hide_render = True
        D.objects["Framing Box"].hide_render = True
        # Deactivate Ambient Occlusion
        C.scene.eevee.use_gtao = False
        # Hide GeoNode modifier
        selected_object = C.selected_objects[0]
        selected_object.modifiers["GeometryNodes"].show_render = False
        # Slot management
        mat = bpy.data.materials.get("c1_prv")
            # Determine whether there are slots to work with
        if len(obj.material_slots) > 0:
            # Assign the material to each slot
            for c, slot in enumerate(obj.material_slots):
                obj.material_slots[c].material = mat
        else:
            # In case there is no material, append the Demo material
            obj.data.materials.append(mat)
        # /////////////////////
        # Configure Compositor
        # Get reference
        node_RL = nodetree.nodes["Render Layers"]
        node_PETrA = nodetree.nodes["PETrA"]
        node_PETrA_Input = node_PETrA.node_tree.nodes["Group Input"]
        node_C1 = node_PETrA.node_tree.nodes["C1_color"]
        node_H = node_PETrA.node_tree.nodes["H_covering"]
        node_L1 = node_PETrA.node_tree.nodes["L1_AO"]
        node_R1 = node_PETrA.node_tree.nodes["R1_shading"]
        node_R2 = node_PETrA.node_tree.nodes["R2_contourLine"]
        node_R3 = node_PETrA.node_tree.nodes["R3_deviationMap"]
        node_R4 = node_PETrA.node_tree.nodes["R4_pointiness"]
        node_R5 = node_PETrA.node_tree.nodes["R5_aspect"]
        node_R6 = node_PETrA.node_tree.nodes["R6_slope"]
        for i in range(10):  # loops through "i = 0 ... 9".
            remove_link(node_RL.outputs[0], node_PETrA.inputs[i])
        remove_link(node_PETrA_Input.outputs[0], node_C1.inputs[0])
        remove_link(node_PETrA_Input.outputs[0], node_C1.inputs[1])
        from petra_blender_addon import popup
        # Get reference
        C = bpy.context
        D = bpy.data
        S = D.scenes["Scene"]
        nodetree = S.node_tree
        node_RL = nodetree.nodes["Render Layers"]
        node_PETrA = nodetree.nodes["PETrA"]
        node_PETrA_Input = node_PETrA.node_tree.nodes["Group Input"]
        node_R4 = node_PETrA.node_tree.nodes["R4_pointiness"]
        gn = D.node_groups["mergeByDistance"] # this is Geometry Nodes
        # Select render Engine
        C.scene.render.engine = "CYCLES"
        # Apply material to selected objects
        material = D.materials["R4_POI"]
        selected_object = C.selected_objects[0]
        selected_object.material_slots[0].material = material
        # Apply material to every selected object
        bpy.ops.object.make_links_data(type='MATERIAL')
        # Render GeoNode modifyer
        selected_object.modifiers["GeometryNodes"].show_render = True
        # Apply modifier to every selected object
        bpy.ops.object.make_links_data(type='MODIFIERS')
        # Set Mesh Resolution  = 1/2
        math1 = gn.nodes["Math1"]
        math1.mute = True
        math2 = gn.nodes["Math2"]
        math2.mute = False
        # Adjust Output filenames (end with -[ratio])
        node_R4_Output = node_R4.node_tree.nodes["File Output"]
        resolution = selected_object.modifiers["GeometryNodes"]["Input_2"]
        resolution_mm = round(resolution*1000, 6)*3
        pattern = f"Cam-##_R4_POI-{resolution_mm}mm"
        node_R4_Output.file_slots[0].path = pattern
        # Create link
        nodetree.links.new(node_RL.outputs[0], node_PETrA.inputs[7])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Rl_R5_Dacf1(bpy.types.Operator):
    bl_idname = "sna.rl_r5_dacf1"
    bl_label = "RL_R5"
    bl_description = "Configuration to generate aspect map"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        ################################################################
        # Setting everything properly to render any layer of information
        # (in case a user change something)
        ################################################################
        import os
        C = bpy.context
        D = bpy.data
        S = D.scenes["Scene"]
        obj = C.object
        nodetree = C.scene.node_tree
        # Don't render `Reference Sphere`
        D.objects["Reference Sphere"].hide_render = True
        ## Render transparent background
        C.scene.render.film_transparent = True
        ## Color management
        C.scene.view_settings.view_transform = "Standard"
        # Hide in render
        D.objects["Reference Sphere"].hide_render = True
        D.objects["Framing Box"].hide_render = True
        # Deactivate Ambient Occlusion
        C.scene.eevee.use_gtao = False
        # Hide GeoNode modifier
        selected_object = C.selected_objects[0]
        selected_object.modifiers["GeometryNodes"].show_render = False
        # Slot management
        mat = bpy.data.materials.get("c1_prv")
            # Determine whether there are slots to work with
        if len(obj.material_slots) > 0:
            # Assign the material to each slot
            for c, slot in enumerate(obj.material_slots):
                obj.material_slots[c].material = mat
        else:
            # In case there is no material, append the Demo material
            obj.data.materials.append(mat)
        # /////////////////////
        # Configure Compositor
        # Get reference
        node_RL = nodetree.nodes["Render Layers"]
        node_PETrA = nodetree.nodes["PETrA"]
        node_PETrA_Input = node_PETrA.node_tree.nodes["Group Input"]
        node_C1 = node_PETrA.node_tree.nodes["C1_color"]
        node_H = node_PETrA.node_tree.nodes["H_covering"]
        node_L1 = node_PETrA.node_tree.nodes["L1_AO"]
        node_R1 = node_PETrA.node_tree.nodes["R1_shading"]
        node_R2 = node_PETrA.node_tree.nodes["R2_contourLine"]
        node_R3 = node_PETrA.node_tree.nodes["R3_deviationMap"]
        node_R4 = node_PETrA.node_tree.nodes["R4_pointiness"]
        node_R5 = node_PETrA.node_tree.nodes["R5_aspect"]
        node_R6 = node_PETrA.node_tree.nodes["R6_slope"]
        for i in range(10):  # loops through "i = 0 ... 9".
            remove_link(node_RL.outputs[0], node_PETrA.inputs[i])
        remove_link(node_PETrA_Input.outputs[0], node_C1.inputs[0])
        remove_link(node_PETrA_Input.outputs[0], node_C1.inputs[1])
        # Get reference
        C = bpy.context
        D = bpy.data
        S = D.scenes["Scene"]
        nodetree = C.scene.node_tree
        node_RL = S.node_tree.nodes["Render Layers"]
        node_PETrA = S.node_tree.nodes["PETrA"]
        # Select render Engine
        C.scene.render.engine = "BLENDER_EEVEE"
        # Apply material
        material = D.materials["R5_ASP"]
        selected_object = C.selected_objects[0]
        selected_object.material_slots[0].material = material
        refSphere = D.objects["Reference Sphere"]
        refSphere.material_slots[0].material = material
        # Apply material to every selected object
        bpy.ops.object.make_links_data(type='MATERIAL')
        # Configure Compositor
        nodetree.links.new(node_RL.outputs[0], node_PETrA.inputs[8])
        # Render `Reference Sphere`
        D.objects["Reference Sphere"].hide_render = False
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Rl_R6_1Fa70(bpy.types.Operator):
    bl_idname = "sna.rl_r6_1fa70"
    bl_label = "RL_R6"
    bl_description = "Configuration to generate slope map"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        ################################################################
        # Setting everything properly to render any layer of information
        # (in case a user change something)
        ################################################################
        import os
        C = bpy.context
        D = bpy.data
        S = D.scenes["Scene"]
        obj = C.object
        nodetree = C.scene.node_tree
        # Don't render `Reference Sphere`
        D.objects["Reference Sphere"].hide_render = True
        ## Render transparent background
        C.scene.render.film_transparent = True
        ## Color management
        C.scene.view_settings.view_transform = "Standard"
        # Hide in render
        D.objects["Reference Sphere"].hide_render = True
        D.objects["Framing Box"].hide_render = True
        # Deactivate Ambient Occlusion
        C.scene.eevee.use_gtao = False
        # Hide GeoNode modifier
        selected_object = C.selected_objects[0]
        selected_object.modifiers["GeometryNodes"].show_render = False
        # Slot management
        mat = bpy.data.materials.get("c1_prv")
            # Determine whether there are slots to work with
        if len(obj.material_slots) > 0:
            # Assign the material to each slot
            for c, slot in enumerate(obj.material_slots):
                obj.material_slots[c].material = mat
        else:
            # In case there is no material, append the Demo material
            obj.data.materials.append(mat)
        # /////////////////////
        # Configure Compositor
        # Get reference
        node_RL = nodetree.nodes["Render Layers"]
        node_PETrA = nodetree.nodes["PETrA"]
        node_PETrA_Input = node_PETrA.node_tree.nodes["Group Input"]
        node_C1 = node_PETrA.node_tree.nodes["C1_color"]
        node_H = node_PETrA.node_tree.nodes["H_covering"]
        node_L1 = node_PETrA.node_tree.nodes["L1_AO"]
        node_R1 = node_PETrA.node_tree.nodes["R1_shading"]
        node_R2 = node_PETrA.node_tree.nodes["R2_contourLine"]
        node_R3 = node_PETrA.node_tree.nodes["R3_deviationMap"]
        node_R4 = node_PETrA.node_tree.nodes["R4_pointiness"]
        node_R5 = node_PETrA.node_tree.nodes["R5_aspect"]
        node_R6 = node_PETrA.node_tree.nodes["R6_slope"]
        for i in range(10):  # loops through "i = 0 ... 9".
            remove_link(node_RL.outputs[0], node_PETrA.inputs[i])
        remove_link(node_PETrA_Input.outputs[0], node_C1.inputs[0])
        remove_link(node_PETrA_Input.outputs[0], node_C1.inputs[1])
        # Get reference
        C = bpy.context
        D = bpy.data
        S = D.scenes["Scene"]
        nodetree = C.scene.node_tree
        node_RL = S.node_tree.nodes["Render Layers"]
        node_PETrA = S.node_tree.nodes["PETrA"]
        # Select render Engine
        C.scene.render.engine = "BLENDER_EEVEE"
        # Apply material
        material = D.materials["R6_SLO"]
        selected_object = C.selected_objects[0]
        selected_object.material_slots[0].material = material
        refSphere = D.objects["Reference Sphere"]
        refSphere.material_slots[0].material = material
        # Apply material to every selected object
        bpy.ops.object.make_links_data(type='MATERIAL')
        # Configure Compositor
        nodetree.links.new(node_RL.outputs[0], node_PETrA.inputs[9])
        # Render `Reference Sphere`
        D.objects["Reference Sphere"].hide_render = False
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Rl_R4_Po1_3E988(bpy.types.Operator):
    bl_idname = "sna.rl_r4_po1_3e988"
    bl_label = "RL_R4_PO1"
    bl_description = "Configuration to generate pointiness (resolution = 1/1)"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        from petra_blender_addon import popup
        # Get reference
        C = bpy.context
        D = bpy.data
        S = D.scenes["Scene"]
        nodetree = S.node_tree
        node_RL = nodetree.nodes["Render Layers"]
        node_PETrA = nodetree.nodes["PETrA"]
        node_PETrA_Input = node_PETrA.node_tree.nodes["Group Input"]
        node_R4 = node_PETrA.node_tree.nodes["R4_pointiness"]
        gn = D.node_groups["mergeByDistance"] # this is Geometry Nodes
        # Select render Engine
        C.scene.render.engine = "CYCLES"
        # Apply material to selected objects
        material = D.materials["R4_POI"]
        selected_object = C.selected_objects[0]
        selected_object.material_slots[0].material = material
        # Apply material to every selected object
        bpy.ops.object.make_links_data(type='MATERIAL')
        # Render GeoNode modifyer
        selected_object.modifiers["GeometryNodes"].show_render = True
        # Apply modifier to every selected object
        bpy.ops.object.make_links_data(type='MODIFIERS')
        # Set Mesh Resolution  = 1
        math1 = gn.nodes["Math1"]
        math1.mute = True
        math2 = gn.nodes["Math2"]
        math2.mute = True
        # Adjust Output filenames (end with -[ratio])
        node_R4_Output = node_R4.node_tree.nodes["File Output"]
        resolution = selected_object.modifiers["GeometryNodes"]["Input_2"]
        resolution_mm = round(resolution*1000, 6)
        pattern = f"Cam-##_R4_POI-{resolution_mm}mm"
        node_R4_Output.file_slots[0].path = pattern
        # Create link
        nodetree.links.new(node_RL.outputs[0], node_PETrA.inputs[7])
        from petra_blender_addon import popup
        # Get reference
        C = bpy.context
        D = bpy.data
        S = D.scenes["Scene"]
        nodetree = S.node_tree
        node_RL = nodetree.nodes["Render Layers"]
        node_PETrA = nodetree.nodes["PETrA"]
        node_PETrA_Input = node_PETrA.node_tree.nodes["Group Input"]
        node_R4 = node_PETrA.node_tree.nodes["R4_pointiness"]
        gn = D.node_groups["mergeByDistance"] # this is Geometry Nodes
        # Select render Engine
        C.scene.render.engine = "CYCLES"
        # Apply material to selected objects
        material = D.materials["R4_POI"]
        selected_object = C.selected_objects[0]
        selected_object.material_slots[0].material = material
        # Apply material to every selected object
        bpy.ops.object.make_links_data(type='MATERIAL')
        # Render GeoNode modifyer
        selected_object.modifiers["GeometryNodes"].show_render = True
        # Apply modifier to every selected object
        bpy.ops.object.make_links_data(type='MODIFIERS')
        # Set Mesh Resolution  = 1
        math1 = gn.nodes["Math1"]
        math1.mute = True
        math2 = gn.nodes["Math2"]
        math2.mute = True
        # Adjust Output filenames (end with -[ratio])
        node_R4_Output = node_R4.node_tree.nodes["File Output"]
        resolution = selected_object.modifiers["GeometryNodes"]["Input_2"]
        resolution_mm = round(resolution*1000, 6)
        pattern = f"Cam-##_R4_POI-{resolution_mm}mm"
        node_R4_Output.file_slots[0].path = pattern
        # Create link
        nodetree.links.new(node_RL.outputs[0], node_PETrA.inputs[7])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Rl_R3_42Fb5(bpy.types.Operator):
    bl_idname = "sna.rl_r3_42fb5"
    bl_label = "RL_R3"
    bl_description = "Configuration to generate deviation maps"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        ################################################################
        # Setting everything properly to render any layer of information
        # (in case a user change something)
        ################################################################
        import os
        C = bpy.context
        D = bpy.data
        S = D.scenes["Scene"]
        obj = C.object
        nodetree = C.scene.node_tree
        # Don't render `Reference Sphere`
        D.objects["Reference Sphere"].hide_render = True
        ## Render transparent background
        C.scene.render.film_transparent = True
        ## Color management
        C.scene.view_settings.view_transform = "Standard"
        # Hide in render
        D.objects["Reference Sphere"].hide_render = True
        D.objects["Framing Box"].hide_render = True
        # Deactivate Ambient Occlusion
        C.scene.eevee.use_gtao = False
        # Hide GeoNode modifier
        selected_object = C.selected_objects[0]
        selected_object.modifiers["GeometryNodes"].show_render = False
        # Slot management
        mat = bpy.data.materials.get("c1_prv")
            # Determine whether there are slots to work with
        if len(obj.material_slots) > 0:
            # Assign the material to each slot
            for c, slot in enumerate(obj.material_slots):
                obj.material_slots[c].material = mat
        else:
            # In case there is no material, append the Demo material
            obj.data.materials.append(mat)
        # /////////////////////
        # Configure Compositor
        # Get reference
        node_RL = nodetree.nodes["Render Layers"]
        node_PETrA = nodetree.nodes["PETrA"]
        node_PETrA_Input = node_PETrA.node_tree.nodes["Group Input"]
        node_C1 = node_PETrA.node_tree.nodes["C1_color"]
        node_H = node_PETrA.node_tree.nodes["H_covering"]
        node_L1 = node_PETrA.node_tree.nodes["L1_AO"]
        node_R1 = node_PETrA.node_tree.nodes["R1_shading"]
        node_R2 = node_PETrA.node_tree.nodes["R2_contourLine"]
        node_R3 = node_PETrA.node_tree.nodes["R3_deviationMap"]
        node_R4 = node_PETrA.node_tree.nodes["R4_pointiness"]
        node_R5 = node_PETrA.node_tree.nodes["R5_aspect"]
        node_R6 = node_PETrA.node_tree.nodes["R6_slope"]
        for i in range(10):  # loops through "i = 0 ... 9".
            remove_link(node_RL.outputs[0], node_PETrA.inputs[i])
        remove_link(node_PETrA_Input.outputs[0], node_C1.inputs[0])
        remove_link(node_PETrA_Input.outputs[0], node_C1.inputs[1])
        # Get reference
        C = bpy.context
        D = bpy.data
        S = D.scenes["Scene"]
        nodetree = C.scene.node_tree
        node_RL = S.node_tree.nodes["Render Layers"]
        node_PETrA = S.node_tree.nodes["PETrA"]
        node_R3 = node_PETrA.node_tree.nodes["R3_deviationMap"]
        # Select render Engine
        C.scene.render.engine = "BLENDER_EEVEE"
        # Apply material to selected objects
        material = D.materials["R3_DM"]
        selected_object = C.selected_objects[0]
        selected_object.material_slots[0].material = material
        # Apply material to every selected object
        bpy.ops.object.make_links_data(type='MATERIAL')
        # Configure Compositor
        nodetree.links.new(node_RL.outputs[0], node_PETrA.inputs[6])
        # Adjust Output filenames
        node_R3_Output0 = node_R3.node_tree.nodes["File Output"]
        node_R3_Output1 = node_R3.node_tree.nodes["File Output.001"]
        R3_ID_full = D.materials["R3_DM"].node_tree.nodes["inputColor"].layer_name
        R3_ID = R3_ID_full[0:3]
        node_R3_Output0.file_slots[0].path = f"Cam-##_R3_{R3_ID}"
        node_R3_Output1.file_slots[0].path = f"Cam-##_R3_{R3_ID_full}_NDG"
        node_R3_Output1.file_slots[1].path = f"Cam-##_R3_{R3_ID_full}_BBR"
        node_R3_Output1.file_slots[2].path = f"Cam-##_R3_{R3_ID_full}_BVJR"
        node_R3_Output1.file_slots[3].path = f"Cam-##_R3_{R3_ID_full}_MAGMA"
        node_R3_Output1.file_slots[4].path = f"Cam-##_R3_{R3_ID_full}_SPECTRAL"
        node_R3_Output1.file_slots[5].path = f"Cam-##_R3_{R3_ID_full}_VIRIDIS"
        node_R3_Output1.file_slots[6].path = f"Cam-##_R3_{R3_ID}_H1"
        #################################################
        # tmp
        tmpR3 = bpy.data.node_groups["R3: Deviation Map"].nodes["tmp_R3"]
        tmpR3.file_slots[0].path = f"Cam-##_R3_{R3_ID}_MAGMA"
        tmpR3.file_slots[1].path = f"Cam-##_R3_{R3_ID}_H1"
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_add_to_petra_pt_material_setup_17CF6(self, context):
    if not (False):
        layout = self.layout
        row_9F505 = layout.row(heading='', align=True)
        row_9F505.alert = False
        row_9F505.enabled = True
        row_9F505.active = True
        row_9F505.use_property_split = False
        row_9F505.use_property_decorate = False
        row_9F505.scale_x = 1.0499999523162842
        row_9F505.scale_y = 1.0
        row_9F505.alignment = 'Expand'.upper()
        op = row_9F505.operator('sna.rl_c1_prt_8b997', text='', icon_value=284, emboss=True, depress=False)
        row_9F505.separator(factor=1.0)
        row_9F505.label(text='C1: Color from texture', icon_value=0)
        row_33573 = layout.row(heading='', align=True)
        row_33573.alert = False
        row_33573.enabled = True
        row_33573.active = True
        row_33573.use_property_split = False
        row_33573.use_property_decorate = False
        row_33573.scale_x = 1.0499999523162842
        row_33573.scale_y = 1.0
        row_33573.alignment = 'Expand'.upper()
        op = row_33573.operator('sna.rl_c1_prv_7f7cc', text='', icon_value=284, emboss=True, depress=False)
        row_33573.separator(factor=1.0)
        row_33573.label(text='C1: Color from vertex', icon_value=0)
        row_2C17A = layout.row(heading='', align=True)
        row_2C17A.alert = False
        row_2C17A.enabled = True
        row_2C17A.active = True
        row_2C17A.use_property_split = False
        row_2C17A.use_property_decorate = False
        row_2C17A.scale_x = 1.0499999523162842
        row_2C17A.scale_y = 1.0
        row_2C17A.alignment = 'Expand'.upper()
        op = row_2C17A.operator('sna.rl_h1_36085', text='', icon_value=284, emboss=True, depress=False)
        row_2C17A.separator(factor=1.0)
        row_2C17A.label(text='H1: Masks', icon_value=0)
        row_0F1E3 = layout.row(heading='', align=True)
        row_0F1E3.alert = False
        row_0F1E3.enabled = True
        row_0F1E3.active = True
        row_0F1E3.use_property_split = False
        row_0F1E3.use_property_decorate = False
        row_0F1E3.scale_x = 1.0499999523162842
        row_0F1E3.scale_y = 1.0
        row_0F1E3.alignment = 'Expand'.upper()
        op = row_0F1E3.operator('sna.rl_h2_b6c13', text='', icon_value=284, emboss=True, depress=False)
        row_0F1E3.separator(factor=1.0)
        row_0F1E3.label(text='H2: Outline By Normals', icon_value=0)
        col_60EA4 = layout.column(heading='', align=False)
        col_60EA4.alert = False
        col_60EA4.enabled = True
        col_60EA4.active = True
        col_60EA4.use_property_split = False
        col_60EA4.use_property_decorate = False
        col_60EA4.scale_x = 1.0
        col_60EA4.scale_y = 1.0
        col_60EA4.alignment = 'Expand'.upper()
        row_60602 = col_60EA4.row(heading='', align=True)
        row_60602.alert = False
        row_60602.enabled = True
        row_60602.active = True
        row_60602.use_property_split = False
        row_60602.use_property_decorate = False
        row_60602.scale_x = 1.0499999523162842
        row_60602.scale_y = 1.0
        row_60602.alignment = 'Expand'.upper()
        op = row_60602.operator('sna.rl_l1_060e0', text='', icon_value=284, emboss=True, depress=False)
        row_60602.separator(factor=1.0)
        row_60602.label(text='L1: Ambient Occlusion', icon_value=0)
        col_7CE13 = col_60EA4.column(heading='', align=True)
        col_7CE13.alert = False
        col_7CE13.enabled = True
        col_7CE13.active = True
        col_7CE13.use_property_split = False
        col_7CE13.use_property_decorate = False
        col_7CE13.scale_x = 1.0
        col_7CE13.scale_y = 1.0
        col_7CE13.alignment = 'Expand'.upper()
        col_7CE13.prop(bpy.data.scenes['Scene'].eevee, 'gtao_distance', text='Distance', icon_value=0, emboss=True)
        col_7CE13.prop(bpy.data.materials['L1_AO'].node_tree.nodes['Brigth_Contrast'].inputs[1], 'default_value', text='Bright (material)', icon_value=0, emboss=True)
        col_7CE13.prop(bpy.data.materials['L1_AO'].node_tree.nodes['Brigth_Contrast'].inputs[2], 'default_value', text='Contrast (material)', icon_value=0, emboss=True)
        row_ABBF2 = layout.row(heading='', align=True)
        row_ABBF2.alert = False
        row_ABBF2.enabled = True
        row_ABBF2.active = True
        row_ABBF2.use_property_split = False
        row_ABBF2.use_property_decorate = False
        row_ABBF2.scale_x = 1.0499999523162842
        row_ABBF2.scale_y = 1.0
        row_ABBF2.alignment = 'Expand'.upper()
        op = row_ABBF2.operator('sna.rl_r1_d5aaf', text='', icon_value=284, emboss=True, depress=False)
        row_ABBF2.separator(factor=1.0)
        row_ABBF2.label(text='R1: Shading', icon_value=0)
        col_37E7F = layout.column(heading='', align=True)
        col_37E7F.alert = False
        col_37E7F.enabled = True
        col_37E7F.active = True
        col_37E7F.use_property_split = False
        col_37E7F.use_property_decorate = False
        col_37E7F.scale_x = 1.0
        col_37E7F.scale_y = 1.0
        col_37E7F.alignment = 'Expand'.upper()
        row_51565 = col_37E7F.row(heading='', align=True)
        row_51565.alert = False
        row_51565.enabled = True
        row_51565.active = True
        row_51565.use_property_split = False
        row_51565.use_property_decorate = False
        row_51565.scale_x = 1.0499999523162842
        row_51565.scale_y = 1.0
        row_51565.alignment = 'Expand'.upper()
        op = row_51565.operator('sna.rl_r2_cl1_05184', text='', icon_value=284, emboss=True, depress=False)
        op = row_51565.operator('sna.rl_r2_cl2_84431', text='', icon_value=284, emboss=True, depress=False)
        op = row_51565.operator('sna.rl_r2_cl3_d27e4', text='', icon_value=284, emboss=True, depress=False)
        row_51565.separator(factor=1.0)
        row_51565.label(text='R2: Contour Lines (x1, x5, x10)', icon_value=0)
        col_37E7F.prop(bpy.data.materials['R2_CL'].node_tree.nodes['value'].outputs[0], 'default_value', text='x1 spacing (in mm)', icon_value=0, emboss=True)
        col_A1D66 = layout.column(heading='', align=True)
        col_A1D66.alert = False
        col_A1D66.enabled = True
        col_A1D66.active = True
        col_A1D66.use_property_split = False
        col_A1D66.use_property_decorate = False
        col_A1D66.scale_x = 1.0
        col_A1D66.scale_y = 1.0
        col_A1D66.alignment = 'Expand'.upper()
        row_AE937 = col_A1D66.row(heading='', align=True)
        row_AE937.alert = False
        row_AE937.enabled = True
        row_AE937.active = True
        row_AE937.use_property_split = False
        row_AE937.use_property_decorate = False
        row_AE937.scale_x = 1.0499999523162842
        row_AE937.scale_y = 1.0
        row_AE937.alignment = 'Expand'.upper()
        op = row_AE937.operator('sna.rl_r3_42fb5', text='', icon_value=284, emboss=True, depress=False)
        row_AE937.separator(factor=1.0)
        row_AE937.label(text='R3: Deviation Map', icon_value=0)
        col_A1D66.prop(bpy.data.scenes['Scene'], 'normValue', text='Min/Max Values', icon_value=0, emboss=True)
        op = col_A1D66.operator('object.generatedistancemap', text='Generate Deviation Map ', icon_value=0, emboss=True, depress=False)
        col_B7E96 = layout.column(heading='', align=True)
        col_B7E96.alert = False
        col_B7E96.enabled = True
        col_B7E96.active = True
        col_B7E96.use_property_split = False
        col_B7E96.use_property_decorate = False
        col_B7E96.scale_x = 1.0
        col_B7E96.scale_y = 1.0
        col_B7E96.alignment = 'Expand'.upper()
        row_0D495 = col_B7E96.row(heading='', align=True)
        row_0D495.alert = False
        row_0D495.enabled = True
        row_0D495.active = True
        row_0D495.use_property_split = False
        row_0D495.use_property_decorate = False
        row_0D495.scale_x = 1.0499999523162842
        row_0D495.scale_y = 1.0
        row_0D495.alignment = 'Expand'.upper()
        op = row_0D495.operator('sna.rl_r4_po1_3e988', text='', icon_value=284, emboss=True, depress=False)
        op = row_0D495.operator('sna.rl_r4_po2_7fcd0', text='', icon_value=284, emboss=True, depress=False)
        op = row_0D495.operator('sna.rl_r4_po3_cefb6', text='', icon_value=284, emboss=True, depress=False)
        row_0D495.separator(factor=1.0)
        row_0D495.label(text='R4: Pointiness', icon_value=0)
        row_3571E = layout.row(heading='', align=True)
        row_3571E.alert = False
        row_3571E.enabled = True
        row_3571E.active = True
        row_3571E.use_property_split = False
        row_3571E.use_property_decorate = False
        row_3571E.scale_x = 1.0499999523162842
        row_3571E.scale_y = 1.0
        row_3571E.alignment = 'Expand'.upper()
        op = row_3571E.operator('sna.rl_r5_dacf1', text='', icon_value=284, emboss=True, depress=False)
        row_3571E.separator(factor=1.0)
        row_3571E.label(text='R5: Aspect', icon_value=0)
        row_5EBE3 = layout.row(heading='', align=True)
        row_5EBE3.alert = False
        row_5EBE3.enabled = True
        row_5EBE3.active = True
        row_5EBE3.use_property_split = False
        row_5EBE3.use_property_decorate = False
        row_5EBE3.scale_x = 1.0499999523162842
        row_5EBE3.scale_y = 1.0
        row_5EBE3.alignment = 'Expand'.upper()
        op = row_5EBE3.operator('sna.rl_r6_1fa70', text='', icon_value=284, emboss=True, depress=False)
        row_5EBE3.separator(factor=1.0)
        row_5EBE3.label(text='R6: Slope', icon_value=0)
        box_CE341 = layout.box()
        box_CE341.alert = False
        box_CE341.enabled = True
        box_CE341.active = True
        box_CE341.use_property_split = False
        box_CE341.use_property_decorate = False
        box_CE341.alignment = 'Expand'.upper()
        box_CE341.scale_x = 1.0
        box_CE341.scale_y = 1.0
        box_CE341.label(text='RENDER SECTION', icon_value=0)
        row_F8232 = box_CE341.row(heading='', align=False)
        row_F8232.alert = False
        row_F8232.enabled = True
        row_F8232.active = True
        row_F8232.use_property_split = False
        row_F8232.use_property_decorate = False
        row_F8232.scale_x = 1.0
        row_F8232.scale_y = 2.0
        row_F8232.alignment = 'Expand'.upper()
        op = row_F8232.operator('cameramanager.render_all_camera', text='Produce documentation', icon_value=0, emboss=True, depress=False)
        col_C9AE6 = box_CE341.column(heading='', align=True)
        col_C9AE6.alert = False
        col_C9AE6.enabled = True
        col_C9AE6.active = True
        col_C9AE6.use_property_split = False
        col_C9AE6.use_property_decorate = False
        col_C9AE6.scale_x = 1.0
        col_C9AE6.scale_y = 1.0
        col_C9AE6.alignment = 'Expand'.upper()
        op = col_C9AE6.operator('petra.export_scene_paradata', text='Export Paradata', icon_value=0, emboss=True, depress=False)
        op = col_C9AE6.operator('sn.dummy_button_operator', text='(Use Converseen)', icon_value=0, emboss=False, depress=False)
        op = col_C9AE6.operator('petra.export_layout_information', text='Export Layout', icon_value=0, emboss=True, depress=False)
        layout.separator(factor=10.0)
        layout.label(text='Not operationnal:', icon_value=0)


class SNA_OT_Rl_C1_Prt_8B997(bpy.types.Operator):
    bl_idname = "sna.rl_c1_prt_8b997"
    bl_label = "RL_C1_PRT"
    bl_description = "Configuration to see the color (from texture)"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        ################################################################
        # Setting everything properly to render any layer of information
        # (in case a user change something)
        ################################################################
        import os
        C = bpy.context
        D = bpy.data
        S = D.scenes["Scene"]
        obj = C.object
        nodetree = C.scene.node_tree
        # Don't render `Reference Sphere`
        D.objects["Reference Sphere"].hide_render = True
        ## Render transparent background
        C.scene.render.film_transparent = True
        ## Color management
        C.scene.view_settings.view_transform = "Standard"
        # Hide in render
        D.objects["Reference Sphere"].hide_render = True
        D.objects["Framing Box"].hide_render = True
        # Deactivate Ambient Occlusion
        C.scene.eevee.use_gtao = False
        # Hide GeoNode modifier
        selected_object = C.selected_objects[0]
        selected_object.modifiers["GeometryNodes"].show_render = False
        # Slot management
        mat = bpy.data.materials.get("c1_prv")
            # Determine whether there are slots to work with
        if len(obj.material_slots) > 0:
            # Assign the material to each slot
            for c, slot in enumerate(obj.material_slots):
                obj.material_slots[c].material = mat
        else:
            # In case there is no material, append the Demo material
            obj.data.materials.append(mat)
        # /////////////////////
        # Configure Compositor
        # Get reference
        node_RL = nodetree.nodes["Render Layers"]
        node_PETrA = nodetree.nodes["PETrA"]
        node_PETrA_Input = node_PETrA.node_tree.nodes["Group Input"]
        node_C1 = node_PETrA.node_tree.nodes["C1_color"]
        node_H = node_PETrA.node_tree.nodes["H_covering"]
        node_L1 = node_PETrA.node_tree.nodes["L1_AO"]
        node_R1 = node_PETrA.node_tree.nodes["R1_shading"]
        node_R2 = node_PETrA.node_tree.nodes["R2_contourLine"]
        node_R3 = node_PETrA.node_tree.nodes["R3_deviationMap"]
        node_R4 = node_PETrA.node_tree.nodes["R4_pointiness"]
        node_R5 = node_PETrA.node_tree.nodes["R5_aspect"]
        node_R6 = node_PETrA.node_tree.nodes["R6_slope"]
        for i in range(10):  # loops through "i = 0 ... 9".
            remove_link(node_RL.outputs[0], node_PETrA.inputs[i])
        remove_link(node_PETrA_Input.outputs[0], node_C1.inputs[0])
        remove_link(node_PETrA_Input.outputs[0], node_C1.inputs[1])
        # Get reference
        C = bpy.context
        D = bpy.data
        S = D.scenes["Scene"]
        nodetree = C.scene.node_tree
        node_RL = S.node_tree.nodes["Render Layers"]
        node_PETrA = S.node_tree.nodes["PETrA"]
        node_PETrA_Input = node_PETrA.node_tree.nodes["Group Input"]
        node_PETrA_nodetree = node_PETrA.node_tree
        node_C1 = node_PETrA.node_tree.nodes["C1_color"]
        # Materials
            # Material should be configured first by user
        # Select render Engine
        C.scene.render.engine = "BLENDER_EEVEE"
        # Configure Compositor
        nodetree.links.new(node_RL.outputs[0], node_PETrA.inputs[0])
        node_PETrA_nodetree.links.new(node_PETrA_Input.outputs[0], node_C1.inputs[0]) # not working
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.PETRA_PT_initial_setup.append(sna_add_to_petra_pt_initial_setup_5B9D4)
    bpy.types.PETRA_PT_initial_setup.prepend(sna_add_to_petra_pt_initial_setup_D7B75)
    bpy.utils.register_class(SNA_OT_Rl_C1_Prv_7F7Cc)
    bpy.utils.register_class(SNA_OT_Rl_H1_36085)
    bpy.utils.register_class(SNA_OT_Rl_H2_B6C13)
    bpy.utils.register_class(SNA_OT_Rl_L1_060E0)
    bpy.utils.register_class(SNA_OT_Rl_R1_D5Aaf)
    bpy.utils.register_class(SNA_OT_Rl_R2_Cl2_84431)
    bpy.utils.register_class(SNA_OT_Rl_R2_Cl3_D27E4)
    bpy.utils.register_class(SNA_OT_Rl_R2_Cl1_05184)
    bpy.utils.register_class(SNA_OT_Rl_R4_Po2_7Fcd0)
    bpy.utils.register_class(SNA_OT_Rl_R4_Po3_Cefb6)
    bpy.utils.register_class(SNA_OT_Rl_R5_Dacf1)
    bpy.utils.register_class(SNA_OT_Rl_R6_1Fa70)
    bpy.utils.register_class(SNA_OT_Rl_R4_Po1_3E988)
    bpy.utils.register_class(SNA_OT_Rl_R3_42Fb5)
    bpy.types.PETRA_PT_material_setup.prepend(sna_add_to_petra_pt_material_setup_17CF6)
    bpy.utils.register_class(SNA_OT_Rl_C1_Prt_8B997)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    bpy.types.PETRA_PT_initial_setup.remove(sna_add_to_petra_pt_initial_setup_5B9D4)
    bpy.types.PETRA_PT_initial_setup.remove(sna_add_to_petra_pt_initial_setup_D7B75)
    bpy.utils.unregister_class(SNA_OT_Rl_C1_Prv_7F7Cc)
    bpy.utils.unregister_class(SNA_OT_Rl_H1_36085)
    bpy.utils.unregister_class(SNA_OT_Rl_H2_B6C13)
    bpy.utils.unregister_class(SNA_OT_Rl_L1_060E0)
    bpy.utils.unregister_class(SNA_OT_Rl_R1_D5Aaf)
    bpy.utils.unregister_class(SNA_OT_Rl_R2_Cl2_84431)
    bpy.utils.unregister_class(SNA_OT_Rl_R2_Cl3_D27E4)
    bpy.utils.unregister_class(SNA_OT_Rl_R2_Cl1_05184)
    bpy.utils.unregister_class(SNA_OT_Rl_R4_Po2_7Fcd0)
    bpy.utils.unregister_class(SNA_OT_Rl_R4_Po3_Cefb6)
    bpy.utils.unregister_class(SNA_OT_Rl_R5_Dacf1)
    bpy.utils.unregister_class(SNA_OT_Rl_R6_1Fa70)
    bpy.utils.unregister_class(SNA_OT_Rl_R4_Po1_3E988)
    bpy.utils.unregister_class(SNA_OT_Rl_R3_42Fb5)
    bpy.types.PETRA_PT_material_setup.remove(sna_add_to_petra_pt_material_setup_17CF6)
    bpy.utils.unregister_class(SNA_OT_Rl_C1_Prt_8B997)
