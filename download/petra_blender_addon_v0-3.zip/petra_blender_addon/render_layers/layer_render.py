import bpy
bpy.ops.render.render(animation=True)
