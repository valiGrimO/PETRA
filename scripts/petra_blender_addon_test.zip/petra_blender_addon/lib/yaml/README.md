PyYAML release 5.4.1
https://github.com/yaml/pyyaml/tree/release/5.4.1/lib3/yaml
